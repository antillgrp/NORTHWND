/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for EmployeeTerritories table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class EmployeeTerritoriesDetailViewModel : ViewModelBase
    {
        private EmployeeTerritoriesData _EmployeeTerritoriesData;
        public EmployeeTerritoriesData EmployeeTerritoriesData
        {
            get
            {
                return _EmployeeTerritoriesData;
            }
            set
            {
                _EmployeeTerritoriesData = value;
                OnPropertyChanged("EmployeeTerritoriesData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public EmployeeTerritoriesDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new EmployeeTerritoriesListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new EmployeeTerritoriesEditViewModel() { ParentWindowViewModel = parent, EmployeeTerritoriesData = this.EmployeeTerritoriesData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this EmployeeTerritories?");
					if (result == MessageBoxResult.Yes)
					{
						var objEmployeeTerritories = p as EmployeeTerritoriesData;
						if (objEmployeeTerritories != null)
						{
							if (EmployeeTerritories.Delete(objEmployeeTerritories.EmployeeID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete EmployeeTerritories {0}  successfully!", objEmployeeTerritories.EmployeeID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new EmployeeTerritoriesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete EmployeeTerritories {0}  fails!", objEmployeeTerritories.EmployeeID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
