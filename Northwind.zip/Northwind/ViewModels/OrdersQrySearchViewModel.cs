/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for OrdersQry
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrdersQrySearchViewModel : ViewModelBase
	{
		#region Private Members
		private OrdersQryData _OrdersQryData;
		private string _filterExpression;
		private OrdersQryListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public OrdersQryData OrdersQryData
		{
			get
			{
				return _OrdersQryData;
			}
			set
			{
				_OrdersQryData = value;
				OnPropertyChanged("OrdersQryData");
			}
		}
		public OrdersQryListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public OrdersQrySearchViewModel()
        {
            try
            {
				this.OrdersQryData = new OrdersQryData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (OrdersQryData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", OrdersQryData.OrderID);
		
					if (OrdersQryData.CustomerID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerID like '%{0}%' AND ", OrdersQryData.CustomerID);
		
					if (OrdersQryData.EmployeeID != 0)
						sbFilterExpression.AppendFormat("EmployeeID = {0} AND ", OrdersQryData.EmployeeID);
		
					if (OrdersQryData.OrderDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("OrderDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(OrdersQryData.OrderDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(OrdersQryData.OrderDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (OrdersQryData.RequiredDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("RequiredDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(OrdersQryData.RequiredDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(OrdersQryData.RequiredDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (OrdersQryData.ShippedDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("ShippedDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(OrdersQryData.ShippedDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(OrdersQryData.ShippedDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (OrdersQryData.ShipVia != 0)
						sbFilterExpression.AppendFormat("ShipVia = {0} AND ", OrdersQryData.ShipVia);
		
					if (OrdersQryData.Freight != 0)
						sbFilterExpression.AppendFormat("Freight = {0} AND ", OrdersQryData.Freight);
		
					if (OrdersQryData.ShipName != string.Empty)
						sbFilterExpression.AppendFormat("ShipName like '%{0}%' AND ", OrdersQryData.ShipName);
		
					if (OrdersQryData.ShipAddress != string.Empty)
						sbFilterExpression.AppendFormat("ShipAddress like '%{0}%' AND ", OrdersQryData.ShipAddress);
		
					if (OrdersQryData.ShipCity != string.Empty)
						sbFilterExpression.AppendFormat("ShipCity like '%{0}%' AND ", OrdersQryData.ShipCity);
		
					if (OrdersQryData.ShipRegion != string.Empty)
						sbFilterExpression.AppendFormat("ShipRegion like '%{0}%' AND ", OrdersQryData.ShipRegion);
		
					if (OrdersQryData.ShipPostalCode != string.Empty)
						sbFilterExpression.AppendFormat("ShipPostalCode like '%{0}%' AND ", OrdersQryData.ShipPostalCode);
		
					if (OrdersQryData.ShipCountry != string.Empty)
						sbFilterExpression.AppendFormat("ShipCountry like '%{0}%' AND ", OrdersQryData.ShipCountry);
		
					if (OrdersQryData.CompanyName != string.Empty)
						sbFilterExpression.AppendFormat("CompanyName like '%{0}%' AND ", OrdersQryData.CompanyName);
		
					if (OrdersQryData.Address != string.Empty)
						sbFilterExpression.AppendFormat("Address like '%{0}%' AND ", OrdersQryData.Address);
		
					if (OrdersQryData.City != string.Empty)
						sbFilterExpression.AppendFormat("City like '%{0}%' AND ", OrdersQryData.City);
		
					if (OrdersQryData.Region != string.Empty)
						sbFilterExpression.AppendFormat("Region like '%{0}%' AND ", OrdersQryData.Region);
		
					if (OrdersQryData.PostalCode != string.Empty)
						sbFilterExpression.AppendFormat("PostalCode like '%{0}%' AND ", OrdersQryData.PostalCode);
		
					if (OrdersQryData.Country != string.Empty)
						sbFilterExpression.AppendFormat("Country like '%{0}%' AND ", OrdersQryData.Country);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					OrdersQryData = null;
					OrdersQryData = new OrdersQryData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return OrdersQryData.IsValid;
			}
		}
    }
}
