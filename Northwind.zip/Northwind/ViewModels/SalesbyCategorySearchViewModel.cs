/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for SalesbyCategory
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class SalesbyCategorySearchViewModel : ViewModelBase
	{
		#region Private Members
		private SalesbyCategoryData _SalesbyCategoryData;
		private string _filterExpression;
		private SalesbyCategoryListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public SalesbyCategoryData SalesbyCategoryData
		{
			get
			{
				return _SalesbyCategoryData;
			}
			set
			{
				_SalesbyCategoryData = value;
				OnPropertyChanged("SalesbyCategoryData");
			}
		}
		public SalesbyCategoryListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public SalesbyCategorySearchViewModel()
        {
            try
            {
				this.SalesbyCategoryData = new SalesbyCategoryData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (SalesbyCategoryData.CategoryID != 0)
						sbFilterExpression.AppendFormat("CategoryID = {0} AND ", SalesbyCategoryData.CategoryID);
		
					if (SalesbyCategoryData.CategoryName != string.Empty)
						sbFilterExpression.AppendFormat("CategoryName like '%{0}%' AND ", SalesbyCategoryData.CategoryName);
		
					if (SalesbyCategoryData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", SalesbyCategoryData.ProductName);
		
					if (SalesbyCategoryData.ProductSales != 0)
						sbFilterExpression.AppendFormat("ProductSales = {0} AND ", SalesbyCategoryData.ProductSales);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					SalesbyCategoryData = null;
					SalesbyCategoryData = new SalesbyCategoryData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return SalesbyCategoryData.IsValid;
			}
		}
    }
}
