/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Shippers
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class ShippersSearchViewModel : ViewModelBase
	{
		#region Private Members
		private ShippersData _ShippersData;
		private string _filterExpression;
		private ShippersListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public ShippersData ShippersData
		{
			get
			{
				return _ShippersData;
			}
			set
			{
				_ShippersData = value;
				OnPropertyChanged("ShippersData");
			}
		}
		public ShippersListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public ShippersSearchViewModel()
        {
            try
            {
				this.ShippersData = new ShippersData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (ShippersData.ShipperID != 0)
						sbFilterExpression.AppendFormat("ShipperID = {0} AND ", ShippersData.ShipperID);
		
					if (ShippersData.CompanyName != string.Empty)
						sbFilterExpression.AppendFormat("CompanyName like '%{0}%' AND ", ShippersData.CompanyName);
		
					if (ShippersData.Phone != string.Empty)
						sbFilterExpression.AppendFormat("Phone like '%{0}%' AND ", ShippersData.Phone);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					ShippersData = null;
					ShippersData = new ShippersData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return ShippersData.IsValid;
			}
		}
    }
}
