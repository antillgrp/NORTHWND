/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for OrderDetails
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrderDetailsSearchViewModel : ViewModelBase
	{
		#region Private Members
		private OrderDetailsData _OrderDetailsData;
		private string _filterExpression;
		private OrderDetailsListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public OrderDetailsData OrderDetailsData
		{
			get
			{
				return _OrderDetailsData;
			}
			set
			{
				_OrderDetailsData = value;
				OnPropertyChanged("OrderDetailsData");
			}
		}
		public OrderDetailsListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public OrderDetailsSearchViewModel()
        {
            try
            {
				this.OrderDetailsData = new OrderDetailsData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (OrderDetailsData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", OrderDetailsData.OrderID);
		
					if (OrderDetailsData.ProductID != 0)
						sbFilterExpression.AppendFormat("ProductID = {0} AND ", OrderDetailsData.ProductID);
		
					if (OrderDetailsData.UnitPrice != 0)
						sbFilterExpression.AppendFormat("UnitPrice = {0} AND ", OrderDetailsData.UnitPrice);
		
					if (OrderDetailsData.Quantity != 0)
						sbFilterExpression.AppendFormat("Quantity = {0} AND ", OrderDetailsData.Quantity);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					OrderDetailsData = null;
					OrderDetailsData = new OrderDetailsData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return OrderDetailsData.IsValid;
			}
		}
    }
}
