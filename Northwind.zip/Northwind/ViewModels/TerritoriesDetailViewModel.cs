/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Territories table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class TerritoriesDetailViewModel : ViewModelBase
    {
        private TerritoriesData _TerritoriesData;
        public TerritoriesData TerritoriesData
        {
            get
            {
                return _TerritoriesData;
            }
            set
            {
                _TerritoriesData = value;
                OnPropertyChanged("TerritoriesData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public TerritoriesDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new TerritoriesListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new TerritoriesEditViewModel() { ParentWindowViewModel = parent, TerritoriesData = this.TerritoriesData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Territories?");
					if (result == MessageBoxResult.Yes)
					{
						var objTerritories = p as TerritoriesData;
						if (objTerritories != null)
						{
							if (Territories.Delete(objTerritories.TerritoryID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Territories {0}  successfully!", objTerritories.TerritoryID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new TerritoriesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete Territories {0}  fails!", objTerritories.TerritoryID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
