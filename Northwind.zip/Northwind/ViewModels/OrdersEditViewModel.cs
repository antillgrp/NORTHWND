/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Orders table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class OrdersEditViewModel : ViewModelBase
    {
        private OrdersData _OrdersData;
        public OrdersData OrdersData
        {
            get { return _OrdersData; }
            set
            {
                _OrdersData = value;
                OnPropertyChanged("OrdersData");
            }
        }

		public List<EmployeesData> EmployeesList { get; set; }
		private int _selectedEmployeeIDIndex;
		public int SelectedEmployeeIDIndex
		{
			get { return _selectedEmployeeIDIndex; }
			set
			{
				_selectedEmployeeIDIndex = (value < 0 ? 0 : value);

				if (OrdersData != null && EmployeesList != null && EmployeesList.Any())
				{
					OrdersData.EmployeeID = EmployeesList[_selectedEmployeeIDIndex].EmployeeID;
				}
				OnPropertyChanged("OrdersData");
				OnPropertyChanged("SelectedEmployeeIDIndex");

			}
		}
		public List<CustomersData> CustomersList { get; set; }
		private int _selectedCustomerIDIndex;
		public int SelectedCustomerIDIndex
		{
			get { return _selectedCustomerIDIndex; }
			set
			{
				_selectedCustomerIDIndex = (value < 0 ? 0 : value);

				if (OrdersData != null && CustomersList != null && CustomersList.Any())
				{
					OrdersData.CustomerID = CustomersList[_selectedCustomerIDIndex].CustomerID;
				}
				OnPropertyChanged("OrdersData");
				OnPropertyChanged("SelectedCustomerIDIndex");

			}
		}

        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public OrdersEditViewModel()
        {
            try
            {
                this.EmployeesList = Employees.GetList("");
				this.EmployeesList.Insert(0, new EmployeesData() { EmployeeID = 0, LastName = "SELECT" });
                this.CustomersList = Customers.GetList("");
				this.CustomersList.Insert(0, new CustomersData() { CustomerID = "", CompanyName = "SELECT" });

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new OrdersListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Orders.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Orders.");

                    if (OrdersData != null)
                    {
                        var OrdersDetail = Orders.GetDetails(OrdersData.OrderID.ToString());
                        bool saveResult;
                        if (OrdersDetail != null && OrdersDetail.Tables.Count > 0 && OrdersDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Orders.Update(OrdersData);
                        }
                        else
                        {
                            saveResult = Orders.Add(OrdersData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new OrdersListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Orders?");
					if (result == MessageBoxResult.Yes)
					{
						var objOrders = p as OrdersData;
						if (objOrders != null)
						{
							if (Orders.Delete(objOrders.OrderID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Orders {0}  successfully!", objOrders.OrderID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new OrdersListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Orders {0}  fails!", objOrders.OrderID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_OrdersData != null)
					return OrdersData.IsValid;
				else
					return false;
				
			}
		}

    }
}
