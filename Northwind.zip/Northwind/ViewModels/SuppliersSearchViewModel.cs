/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Suppliers
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class SuppliersSearchViewModel : ViewModelBase
	{
		#region Private Members
		private SuppliersData _SuppliersData;
		private string _filterExpression;
		private SuppliersListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public SuppliersData SuppliersData
		{
			get
			{
				return _SuppliersData;
			}
			set
			{
				_SuppliersData = value;
				OnPropertyChanged("SuppliersData");
			}
		}
		public SuppliersListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public SuppliersSearchViewModel()
        {
            try
            {
				this.SuppliersData = new SuppliersData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (SuppliersData.SupplierID != 0)
						sbFilterExpression.AppendFormat("SupplierID = {0} AND ", SuppliersData.SupplierID);
		
					if (SuppliersData.CompanyName != string.Empty)
						sbFilterExpression.AppendFormat("CompanyName like '%{0}%' AND ", SuppliersData.CompanyName);
		
					if (SuppliersData.ContactName != string.Empty)
						sbFilterExpression.AppendFormat("ContactName like '%{0}%' AND ", SuppliersData.ContactName);
		
					if (SuppliersData.ContactTitle != string.Empty)
						sbFilterExpression.AppendFormat("ContactTitle like '%{0}%' AND ", SuppliersData.ContactTitle);
		
					if (SuppliersData.Address != string.Empty)
						sbFilterExpression.AppendFormat("Address like '%{0}%' AND ", SuppliersData.Address);
		
					if (SuppliersData.City != string.Empty)
						sbFilterExpression.AppendFormat("City like '%{0}%' AND ", SuppliersData.City);
		
					if (SuppliersData.Region != string.Empty)
						sbFilterExpression.AppendFormat("Region like '%{0}%' AND ", SuppliersData.Region);
		
					if (SuppliersData.PostalCode != string.Empty)
						sbFilterExpression.AppendFormat("PostalCode like '%{0}%' AND ", SuppliersData.PostalCode);
		
					if (SuppliersData.Country != string.Empty)
						sbFilterExpression.AppendFormat("Country like '%{0}%' AND ", SuppliersData.Country);
		
					if (SuppliersData.Phone != string.Empty)
						sbFilterExpression.AppendFormat("Phone like '%{0}%' AND ", SuppliersData.Phone);
		
					if (SuppliersData.Fax != string.Empty)
						sbFilterExpression.AppendFormat("Fax like '%{0}%' AND ", SuppliersData.Fax);
		
					if (SuppliersData.HomePage != string.Empty)
						sbFilterExpression.AppendFormat("HomePage like '%{0}%' AND ", SuppliersData.HomePage);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					SuppliersData = null;
					SuppliersData = new SuppliersData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return SuppliersData.IsValid;
			}
		}
    }
}
