/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for ProductSalesfor1997
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class ProductSalesfor1997SearchViewModel : ViewModelBase
	{
		#region Private Members
		private ProductSalesfor1997Data _ProductSalesfor1997Data;
		private string _filterExpression;
		private ProductSalesfor1997ListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public ProductSalesfor1997Data ProductSalesfor1997Data
		{
			get
			{
				return _ProductSalesfor1997Data;
			}
			set
			{
				_ProductSalesfor1997Data = value;
				OnPropertyChanged("ProductSalesfor1997Data");
			}
		}
		public ProductSalesfor1997ListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public ProductSalesfor1997SearchViewModel()
        {
            try
            {
				this.ProductSalesfor1997Data = new ProductSalesfor1997Data();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (ProductSalesfor1997Data.CategoryName != string.Empty)
						sbFilterExpression.AppendFormat("CategoryName like '%{0}%' AND ", ProductSalesfor1997Data.CategoryName);
		
					if (ProductSalesfor1997Data.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", ProductSalesfor1997Data.ProductName);
		
					if (ProductSalesfor1997Data.ProductSales != 0)
						sbFilterExpression.AppendFormat("ProductSales = {0} AND ", ProductSalesfor1997Data.ProductSales);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					ProductSalesfor1997Data = null;
					ProductSalesfor1997Data = new ProductSalesfor1997Data();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return ProductSalesfor1997Data.IsValid;
			}
		}
    }
}
