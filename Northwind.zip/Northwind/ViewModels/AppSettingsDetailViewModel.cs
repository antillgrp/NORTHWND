/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for AppSettings table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class AppSettingsDetailViewModel : ViewModelBase
    {
        private AppSettingsData _AppSettingsData;
        public AppSettingsData AppSettingsData
        {
            get
            {
                return _AppSettingsData;
            }
            set
            {
                _AppSettingsData = value;
                OnPropertyChanged("AppSettingsData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public AppSettingsDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new AppSettingsListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new AppSettingsEditViewModel() { ParentWindowViewModel = parent, AppSettingsData = this.AppSettingsData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this AppSettings?");
					if (result == MessageBoxResult.Yes)
					{
						var objAppSettings = p as AppSettingsData;
						if (objAppSettings != null)
						{
							if (AppSettings.Delete(objAppSettings.OptionID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete AppSettings {0}  successfully!", objAppSettings.OptionID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new AppSettingsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete AppSettings {0}  fails!", objAppSettings.OptionID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
