/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Customers
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CustomersSearchViewModel : ViewModelBase
	{
		#region Private Members
		private CustomersData _CustomersData;
		private string _filterExpression;
		private CustomersListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public CustomersData CustomersData
		{
			get
			{
				return _CustomersData;
			}
			set
			{
				_CustomersData = value;
				OnPropertyChanged("CustomersData");
			}
		}
		public CustomersListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public CustomersSearchViewModel()
        {
            try
            {
				this.CustomersData = new CustomersData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (CustomersData.CustomerID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerID like '%{0}%' AND ", CustomersData.CustomerID);
		
					if (CustomersData.CompanyName != string.Empty)
						sbFilterExpression.AppendFormat("CompanyName like '%{0}%' AND ", CustomersData.CompanyName);
		
					if (CustomersData.ContactName != string.Empty)
						sbFilterExpression.AppendFormat("ContactName like '%{0}%' AND ", CustomersData.ContactName);
		
					if (CustomersData.ContactTitle != string.Empty)
						sbFilterExpression.AppendFormat("ContactTitle like '%{0}%' AND ", CustomersData.ContactTitle);
		
					if (CustomersData.Address != string.Empty)
						sbFilterExpression.AppendFormat("Address like '%{0}%' AND ", CustomersData.Address);
		
					if (CustomersData.City != string.Empty)
						sbFilterExpression.AppendFormat("City like '%{0}%' AND ", CustomersData.City);
		
					if (CustomersData.Region != string.Empty)
						sbFilterExpression.AppendFormat("Region like '%{0}%' AND ", CustomersData.Region);
		
					if (CustomersData.PostalCode != string.Empty)
						sbFilterExpression.AppendFormat("PostalCode like '%{0}%' AND ", CustomersData.PostalCode);
		
					if (CustomersData.Country != string.Empty)
						sbFilterExpression.AppendFormat("Country like '%{0}%' AND ", CustomersData.Country);
		
					if (CustomersData.Phone != string.Empty)
						sbFilterExpression.AppendFormat("Phone like '%{0}%' AND ", CustomersData.Phone);
		
					if (CustomersData.Fax != string.Empty)
						sbFilterExpression.AppendFormat("Fax like '%{0}%' AND ", CustomersData.Fax);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					CustomersData = null;
					CustomersData = new CustomersData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return CustomersData.IsValid;
			}
		}
    }
}
