/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Employees
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class EmployeesSearchViewModel : ViewModelBase
	{
		#region Private Members
		private EmployeesData _EmployeesData;
		private string _filterExpression;
		private EmployeesListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public EmployeesData EmployeesData
		{
			get
			{
				return _EmployeesData;
			}
			set
			{
				_EmployeesData = value;
				OnPropertyChanged("EmployeesData");
			}
		}
		public EmployeesListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public EmployeesSearchViewModel()
        {
            try
            {
				this.EmployeesData = new EmployeesData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (EmployeesData.EmployeeID != 0)
						sbFilterExpression.AppendFormat("EmployeeID = {0} AND ", EmployeesData.EmployeeID);
		
					if (EmployeesData.LastName != string.Empty)
						sbFilterExpression.AppendFormat("LastName like '%{0}%' AND ", EmployeesData.LastName);
		
					if (EmployeesData.FirstName != string.Empty)
						sbFilterExpression.AppendFormat("FirstName like '%{0}%' AND ", EmployeesData.FirstName);
		
					if (EmployeesData.Title != string.Empty)
						sbFilterExpression.AppendFormat("Title like '%{0}%' AND ", EmployeesData.Title);
		
					if (EmployeesData.TitleOfCourtesy != string.Empty)
						sbFilterExpression.AppendFormat("TitleOfCourtesy like '%{0}%' AND ", EmployeesData.TitleOfCourtesy);
		
					if (EmployeesData.BirthDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("BirthDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(EmployeesData.BirthDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(EmployeesData.BirthDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (EmployeesData.HireDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("HireDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(EmployeesData.HireDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(EmployeesData.HireDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (EmployeesData.Address != string.Empty)
						sbFilterExpression.AppendFormat("Address like '%{0}%' AND ", EmployeesData.Address);
		
					if (EmployeesData.City != string.Empty)
						sbFilterExpression.AppendFormat("City like '%{0}%' AND ", EmployeesData.City);
		
					if (EmployeesData.Region != string.Empty)
						sbFilterExpression.AppendFormat("Region like '%{0}%' AND ", EmployeesData.Region);
		
					if (EmployeesData.PostalCode != string.Empty)
						sbFilterExpression.AppendFormat("PostalCode like '%{0}%' AND ", EmployeesData.PostalCode);
		
					if (EmployeesData.Country != string.Empty)
						sbFilterExpression.AppendFormat("Country like '%{0}%' AND ", EmployeesData.Country);
		
					if (EmployeesData.HomePhone != string.Empty)
						sbFilterExpression.AppendFormat("HomePhone like '%{0}%' AND ", EmployeesData.HomePhone);
		
					if (EmployeesData.Extension != string.Empty)
						sbFilterExpression.AppendFormat("Extension like '%{0}%' AND ", EmployeesData.Extension);
		
					if (EmployeesData.Notes != string.Empty)
						sbFilterExpression.AppendFormat("Notes like '%{0}%' AND ", EmployeesData.Notes);
		
					if (EmployeesData.ReportsTo != 0)
						sbFilterExpression.AppendFormat("ReportsTo = {0} AND ", EmployeesData.ReportsTo);
		
					if (EmployeesData.PhotoPath != string.Empty)
						sbFilterExpression.AppendFormat("PhotoPath like '%{0}%' AND ", EmployeesData.PhotoPath);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					EmployeesData = null;
					EmployeesData = new EmployeesData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return EmployeesData.IsValid;
			}
		}
    }
}
