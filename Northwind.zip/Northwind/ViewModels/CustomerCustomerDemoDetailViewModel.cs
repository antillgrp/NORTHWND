/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CustomerCustomerDemo table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CustomerCustomerDemoDetailViewModel : ViewModelBase
    {
        private CustomerCustomerDemoData _CustomerCustomerDemoData;
        public CustomerCustomerDemoData CustomerCustomerDemoData
        {
            get
            {
                return _CustomerCustomerDemoData;
            }
            set
            {
                _CustomerCustomerDemoData = value;
                OnPropertyChanged("CustomerCustomerDemoData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public CustomerCustomerDemoDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CustomerCustomerDemoListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CustomerCustomerDemoEditViewModel() { ParentWindowViewModel = parent, CustomerCustomerDemoData = this.CustomerCustomerDemoData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this CustomerCustomerDemo?");
					if (result == MessageBoxResult.Yes)
					{
						var objCustomerCustomerDemo = p as CustomerCustomerDemoData;
						if (objCustomerCustomerDemo != null)
						{
							if (CustomerCustomerDemo.Delete(objCustomerCustomerDemo.CustomerID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete CustomerCustomerDemo {0}  successfully!", objCustomerCustomerDemo.CustomerID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new CustomerCustomerDemoListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete CustomerCustomerDemo {0}  fails!", objCustomerCustomerDemo.CustomerID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
