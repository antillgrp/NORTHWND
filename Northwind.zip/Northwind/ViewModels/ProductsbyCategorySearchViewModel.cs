/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for ProductsbyCategory
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class ProductsbyCategorySearchViewModel : ViewModelBase
	{
		#region Private Members
		private ProductsbyCategoryData _ProductsbyCategoryData;
		private string _filterExpression;
		private ProductsbyCategoryListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public ProductsbyCategoryData ProductsbyCategoryData
		{
			get
			{
				return _ProductsbyCategoryData;
			}
			set
			{
				_ProductsbyCategoryData = value;
				OnPropertyChanged("ProductsbyCategoryData");
			}
		}
		public ProductsbyCategoryListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public ProductsbyCategorySearchViewModel()
        {
            try
            {
				this.ProductsbyCategoryData = new ProductsbyCategoryData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (ProductsbyCategoryData.CategoryName != string.Empty)
						sbFilterExpression.AppendFormat("CategoryName like '%{0}%' AND ", ProductsbyCategoryData.CategoryName);
		
					if (ProductsbyCategoryData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", ProductsbyCategoryData.ProductName);
		
					if (ProductsbyCategoryData.QuantityPerUnit != string.Empty)
						sbFilterExpression.AppendFormat("QuantityPerUnit like '%{0}%' AND ", ProductsbyCategoryData.QuantityPerUnit);
		
					if (ProductsbyCategoryData.UnitsInStock != 0)
						sbFilterExpression.AppendFormat("UnitsInStock = {0} AND ", ProductsbyCategoryData.UnitsInStock);
		
					if (ProductsbyCategoryData.Discontinued)
						sbFilterExpression.AppendFormat("Discontinued = '{0}' AND ", (ProductsbyCategoryData.Discontinued == true? 1 : 0).ToString());
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					ProductsbyCategoryData = null;
					ProductsbyCategoryData = new ProductsbyCategoryData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return ProductsbyCategoryData.IsValid;
			}
		}
    }
}
