/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Products
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class ProductsSearchViewModel : ViewModelBase
	{
		#region Private Members
		private ProductsData _ProductsData;
		private string _filterExpression;
		private ProductsListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public ProductsData ProductsData
		{
			get
			{
				return _ProductsData;
			}
			set
			{
				_ProductsData = value;
				OnPropertyChanged("ProductsData");
			}
		}
		public ProductsListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists
		public List<SuppliersData> SuppliersList { get; set; }
		private int _selectedSupplierIDIndex;
		public int SelectedSupplierIDIndex
		{
			get { return _selectedSupplierIDIndex; }
			set
			{
				_selectedSupplierIDIndex = (value < 0 ? 0 : value);
				if (ProductsData != null && SuppliersList != null && SuppliersList.Any())
				{
					ProductsData.SupplierID = SuppliersList[_selectedSupplierIDIndex].SupplierID;
				}
				OnPropertyChanged("ProductsData");
				OnPropertyChanged("SelectedSupplierIDIndex");
			}
		}
		public List<CategoriesData> CategoriesList { get; set; }
		private int _selectedCategoryIDIndex;
		public int SelectedCategoryIDIndex
		{
			get { return _selectedCategoryIDIndex; }
			set
			{
				_selectedCategoryIDIndex = (value < 0 ? 0 : value);
				if (ProductsData != null && CategoriesList != null && CategoriesList.Any())
				{
					ProductsData.CategoryID = CategoriesList[_selectedCategoryIDIndex].CategoryID;
				}
				OnPropertyChanged("ProductsData");
				OnPropertyChanged("SelectedCategoryIDIndex");
			}
		}

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public ProductsSearchViewModel()
        {
            try
            {
				this.ProductsData = new ProductsData();
                this.SuppliersList = Suppliers.GetList("");
				this.SuppliersList.Insert(0, new SuppliersData() { SupplierID = 0, CompanyName = "SELECT" });
                this.CategoriesList = Categories.GetList("");
				this.CategoriesList.Insert(0, new CategoriesData() { CategoryID = 0, CategoryName = "SELECT" });

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (ProductsData.ProductID != 0)
						sbFilterExpression.AppendFormat("ProductID = {0} AND ", ProductsData.ProductID);
		
					if (ProductsData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", ProductsData.ProductName);
		
					if (ProductsData.SupplierID != 0)
						sbFilterExpression.AppendFormat("SupplierID = {0} AND ", ProductsData.SupplierID);
		
					if (ProductsData.CategoryID != 0)
						sbFilterExpression.AppendFormat("CategoryID = {0} AND ", ProductsData.CategoryID);
		
					if (ProductsData.QuantityPerUnit != string.Empty)
						sbFilterExpression.AppendFormat("QuantityPerUnit like '%{0}%' AND ", ProductsData.QuantityPerUnit);
		
					if (ProductsData.UnitPrice != 0)
						sbFilterExpression.AppendFormat("UnitPrice = {0} AND ", ProductsData.UnitPrice);
		
					if (ProductsData.UnitsInStock != 0)
						sbFilterExpression.AppendFormat("UnitsInStock = {0} AND ", ProductsData.UnitsInStock);
		
					if (ProductsData.UnitsOnOrder != 0)
						sbFilterExpression.AppendFormat("UnitsOnOrder = {0} AND ", ProductsData.UnitsOnOrder);
		
					if (ProductsData.ReorderLevel != 0)
						sbFilterExpression.AppendFormat("ReorderLevel = {0} AND ", ProductsData.ReorderLevel);
		
					if (ProductsData.Discontinued)
						sbFilterExpression.AppendFormat("Discontinued = '{0}' AND ", (ProductsData.Discontinued == true? 1 : 0).ToString());
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					ProductsData = null;
					ProductsData = new ProductsData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return ProductsData.IsValid;
			}
		}
    }
}
