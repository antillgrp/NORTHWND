/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CategorySalesfor1997 view
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CategorySalesfor1997DetailViewModel : ViewModelBase
    {
        private CategorySalesfor1997Data _CategorySalesfor1997Data;
        public CategorySalesfor1997Data CategorySalesfor1997Data
        {
            get
            {
                return _CategorySalesfor1997Data;
            }
            set
            {
                _CategorySalesfor1997Data = value;
                OnPropertyChanged("CategorySalesfor1997Data");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public CategorySalesfor1997DetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CategorySalesfor1997ListViewModel() { ParentWindowViewModel = parent };
                    }
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
