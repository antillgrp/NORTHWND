/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CustomerDemographics
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CustomerDemographicsSearchViewModel : ViewModelBase
	{
		#region Private Members
		private CustomerDemographicsData _CustomerDemographicsData;
		private string _filterExpression;
		private CustomerDemographicsListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public CustomerDemographicsData CustomerDemographicsData
		{
			get
			{
				return _CustomerDemographicsData;
			}
			set
			{
				_CustomerDemographicsData = value;
				OnPropertyChanged("CustomerDemographicsData");
			}
		}
		public CustomerDemographicsListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public CustomerDemographicsSearchViewModel()
        {
            try
            {
				this.CustomerDemographicsData = new CustomerDemographicsData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (CustomerDemographicsData.CustomerTypeID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerTypeID like '%{0}%' AND ", CustomerDemographicsData.CustomerTypeID);
		
					if (CustomerDemographicsData.CustomerDesc != string.Empty)
						sbFilterExpression.AppendFormat("CustomerDesc like '%{0}%' AND ", CustomerDemographicsData.CustomerDesc);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					CustomerDemographicsData = null;
					CustomerDemographicsData = new CustomerDemographicsData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return CustomerDemographicsData.IsValid;
			}
		}
    }
}
