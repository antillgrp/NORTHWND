/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for OrderSubtotals view
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrderSubtotalsDetailViewModel : ViewModelBase
    {
        private OrderSubtotalsData _OrderSubtotalsData;
        public OrderSubtotalsData OrderSubtotalsData
        {
            get
            {
                return _OrderSubtotalsData;
            }
            set
            {
                _OrderSubtotalsData = value;
                OnPropertyChanged("OrderSubtotalsData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public OrderSubtotalsDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new OrderSubtotalsListViewModel() { ParentWindowViewModel = parent };
                    }
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
