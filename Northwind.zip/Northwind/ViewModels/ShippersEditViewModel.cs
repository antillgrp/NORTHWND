/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Shippers table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class ShippersEditViewModel : ViewModelBase
    {
        private ShippersData _ShippersData;
        public ShippersData ShippersData
        {
            get { return _ShippersData; }
            set
            {
                _ShippersData = value;
                OnPropertyChanged("ShippersData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ShippersEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new ShippersListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Shippers.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Shippers.");

                    if (ShippersData != null)
                    {
                        var ShippersDetail = Shippers.GetDetails(ShippersData.ShipperID.ToString());
                        bool saveResult;
                        if (ShippersDetail != null && ShippersDetail.Tables.Count > 0 && ShippersDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Shippers.Update(ShippersData);
                        }
                        else
                        {
                            saveResult = Shippers.Add(ShippersData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new ShippersListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Shippers?");
					if (result == MessageBoxResult.Yes)
					{
						var objShippers = p as ShippersData;
						if (objShippers != null)
						{
							if (Shippers.Delete(objShippers.ShipperID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Shippers {0}  successfully!", objShippers.ShipperID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new ShippersListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Shippers {0}  fails!", objShippers.ShipperID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_ShippersData != null)
					return ShippersData.IsValid;
				else
					return false;
				
			}
		}

    }
}
