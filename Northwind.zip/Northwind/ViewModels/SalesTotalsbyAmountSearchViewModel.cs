/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for SalesTotalsbyAmount
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class SalesTotalsbyAmountSearchViewModel : ViewModelBase
	{
		#region Private Members
		private SalesTotalsbyAmountData _SalesTotalsbyAmountData;
		private string _filterExpression;
		private SalesTotalsbyAmountListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public SalesTotalsbyAmountData SalesTotalsbyAmountData
		{
			get
			{
				return _SalesTotalsbyAmountData;
			}
			set
			{
				_SalesTotalsbyAmountData = value;
				OnPropertyChanged("SalesTotalsbyAmountData");
			}
		}
		public SalesTotalsbyAmountListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public SalesTotalsbyAmountSearchViewModel()
        {
            try
            {
				this.SalesTotalsbyAmountData = new SalesTotalsbyAmountData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (SalesTotalsbyAmountData.SaleAmount != 0)
						sbFilterExpression.AppendFormat("SaleAmount = {0} AND ", SalesTotalsbyAmountData.SaleAmount);
		
					if (SalesTotalsbyAmountData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", SalesTotalsbyAmountData.OrderID);
		
					if (SalesTotalsbyAmountData.CompanyName != string.Empty)
						sbFilterExpression.AppendFormat("CompanyName like '%{0}%' AND ", SalesTotalsbyAmountData.CompanyName);
		
					if (SalesTotalsbyAmountData.ShippedDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("ShippedDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(SalesTotalsbyAmountData.ShippedDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(SalesTotalsbyAmountData.ShippedDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					SalesTotalsbyAmountData = null;
					SalesTotalsbyAmountData = new SalesTotalsbyAmountData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return SalesTotalsbyAmountData.IsValid;
			}
		}
    }
}
