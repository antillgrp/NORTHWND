/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CustomerCustomerDemo
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CustomerCustomerDemoSearchViewModel : ViewModelBase
	{
		#region Private Members
		private CustomerCustomerDemoData _CustomerCustomerDemoData;
		private string _filterExpression;
		private CustomerCustomerDemoListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public CustomerCustomerDemoData CustomerCustomerDemoData
		{
			get
			{
				return _CustomerCustomerDemoData;
			}
			set
			{
				_CustomerCustomerDemoData = value;
				OnPropertyChanged("CustomerCustomerDemoData");
			}
		}
		public CustomerCustomerDemoListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public CustomerCustomerDemoSearchViewModel()
        {
            try
            {
				this.CustomerCustomerDemoData = new CustomerCustomerDemoData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (CustomerCustomerDemoData.CustomerID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerID like '%{0}%' AND ", CustomerCustomerDemoData.CustomerID);
		
					if (CustomerCustomerDemoData.CustomerTypeID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerTypeID like '%{0}%' AND ", CustomerCustomerDemoData.CustomerTypeID);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					CustomerCustomerDemoData = null;
					CustomerCustomerDemoData = new CustomerCustomerDemoData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return CustomerCustomerDemoData.IsValid;
			}
		}
    }
}
