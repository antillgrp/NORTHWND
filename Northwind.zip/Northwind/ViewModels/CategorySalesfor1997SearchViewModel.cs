/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CategorySalesfor1997
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CategorySalesfor1997SearchViewModel : ViewModelBase
	{
		#region Private Members
		private CategorySalesfor1997Data _CategorySalesfor1997Data;
		private string _filterExpression;
		private CategorySalesfor1997ListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public CategorySalesfor1997Data CategorySalesfor1997Data
		{
			get
			{
				return _CategorySalesfor1997Data;
			}
			set
			{
				_CategorySalesfor1997Data = value;
				OnPropertyChanged("CategorySalesfor1997Data");
			}
		}
		public CategorySalesfor1997ListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public CategorySalesfor1997SearchViewModel()
        {
            try
            {
				this.CategorySalesfor1997Data = new CategorySalesfor1997Data();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (CategorySalesfor1997Data.CategoryName != string.Empty)
						sbFilterExpression.AppendFormat("CategoryName like '%{0}%' AND ", CategorySalesfor1997Data.CategoryName);
		
					if (CategorySalesfor1997Data.CategorySales != 0)
						sbFilterExpression.AppendFormat("CategorySales = {0} AND ", CategorySalesfor1997Data.CategorySales);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					CategorySalesfor1997Data = null;
					CategorySalesfor1997Data = new CategorySalesfor1997Data();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return CategorySalesfor1997Data.IsValid;
			}
		}
    }
}
