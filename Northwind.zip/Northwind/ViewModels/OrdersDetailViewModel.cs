/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Orders table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrdersDetailViewModel : ViewModelBase
    {
        private OrdersData _OrdersData;
        public OrdersData OrdersData
        {
            get
            {
                return _OrdersData;
            }
            set
            {
                _OrdersData = value;
                OnPropertyChanged("OrdersData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public OrdersDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new OrdersListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new OrdersEditViewModel() { ParentWindowViewModel = parent, OrdersData = this.OrdersData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Orders?");
					if (result == MessageBoxResult.Yes)
					{
						var objOrders = p as OrdersData;
						if (objOrders != null)
						{
							if (Orders.Delete(objOrders.OrderID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Orders {0}  successfully!", objOrders.OrderID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new OrdersListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete Orders {0}  fails!", objOrders.OrderID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
