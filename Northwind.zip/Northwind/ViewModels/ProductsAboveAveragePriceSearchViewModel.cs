/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for ProductsAboveAveragePrice
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class ProductsAboveAveragePriceSearchViewModel : ViewModelBase
	{
		#region Private Members
		private ProductsAboveAveragePriceData _ProductsAboveAveragePriceData;
		private string _filterExpression;
		private ProductsAboveAveragePriceListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public ProductsAboveAveragePriceData ProductsAboveAveragePriceData
		{
			get
			{
				return _ProductsAboveAveragePriceData;
			}
			set
			{
				_ProductsAboveAveragePriceData = value;
				OnPropertyChanged("ProductsAboveAveragePriceData");
			}
		}
		public ProductsAboveAveragePriceListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public ProductsAboveAveragePriceSearchViewModel()
        {
            try
            {
				this.ProductsAboveAveragePriceData = new ProductsAboveAveragePriceData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (ProductsAboveAveragePriceData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", ProductsAboveAveragePriceData.ProductName);
		
					if (ProductsAboveAveragePriceData.UnitPrice != 0)
						sbFilterExpression.AppendFormat("UnitPrice = {0} AND ", ProductsAboveAveragePriceData.UnitPrice);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					ProductsAboveAveragePriceData = null;
					ProductsAboveAveragePriceData = new ProductsAboveAveragePriceData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return ProductsAboveAveragePriceData.IsValid;
			}
		}
    }
}
