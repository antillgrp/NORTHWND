/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Employees table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class EmployeesEditViewModel : ViewModelBase
    {
        private EmployeesData _EmployeesData;
        public EmployeesData EmployeesData
        {
            get { return _EmployeesData; }
            set
            {
                _EmployeesData = value;
                OnPropertyChanged("EmployeesData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public EmployeesEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new EmployeesListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Employees.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Employees.");

                    if (EmployeesData != null)
                    {
                        var EmployeesDetail = Employees.GetDetails(EmployeesData.EmployeeID.ToString());
                        bool saveResult;
                        if (EmployeesDetail != null && EmployeesDetail.Tables.Count > 0 && EmployeesDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Employees.Update(EmployeesData);
                        }
                        else
                        {
                            saveResult = Employees.Add(EmployeesData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new EmployeesListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Employees?");
					if (result == MessageBoxResult.Yes)
					{
						var objEmployees = p as EmployeesData;
						if (objEmployees != null)
						{
							if (Employees.Delete(objEmployees.EmployeeID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Employees {0}  successfully!", objEmployees.EmployeeID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new EmployeesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Employees {0}  fails!", objEmployees.EmployeeID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_EmployeesData != null)
					return EmployeesData.IsValid;
				else
					return false;
				
			}
		}

    }
}
