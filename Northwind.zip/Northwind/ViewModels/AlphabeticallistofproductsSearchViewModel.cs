/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Alphabeticallistofproducts
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class AlphabeticallistofproductsSearchViewModel : ViewModelBase
	{
		#region Private Members
		private AlphabeticallistofproductsData _AlphabeticallistofproductsData;
		private string _filterExpression;
		private AlphabeticallistofproductsListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public AlphabeticallistofproductsData AlphabeticallistofproductsData
		{
			get
			{
				return _AlphabeticallistofproductsData;
			}
			set
			{
				_AlphabeticallistofproductsData = value;
				OnPropertyChanged("AlphabeticallistofproductsData");
			}
		}
		public AlphabeticallistofproductsListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public AlphabeticallistofproductsSearchViewModel()
        {
            try
            {
				this.AlphabeticallistofproductsData = new AlphabeticallistofproductsData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (AlphabeticallistofproductsData.ProductID != 0)
						sbFilterExpression.AppendFormat("ProductID = {0} AND ", AlphabeticallistofproductsData.ProductID);
		
					if (AlphabeticallistofproductsData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", AlphabeticallistofproductsData.ProductName);
		
					if (AlphabeticallistofproductsData.SupplierID != 0)
						sbFilterExpression.AppendFormat("SupplierID = {0} AND ", AlphabeticallistofproductsData.SupplierID);
		
					if (AlphabeticallistofproductsData.CategoryID != 0)
						sbFilterExpression.AppendFormat("CategoryID = {0} AND ", AlphabeticallistofproductsData.CategoryID);
		
					if (AlphabeticallistofproductsData.QuantityPerUnit != string.Empty)
						sbFilterExpression.AppendFormat("QuantityPerUnit like '%{0}%' AND ", AlphabeticallistofproductsData.QuantityPerUnit);
		
					if (AlphabeticallistofproductsData.UnitPrice != 0)
						sbFilterExpression.AppendFormat("UnitPrice = {0} AND ", AlphabeticallistofproductsData.UnitPrice);
		
					if (AlphabeticallistofproductsData.UnitsInStock != 0)
						sbFilterExpression.AppendFormat("UnitsInStock = {0} AND ", AlphabeticallistofproductsData.UnitsInStock);
		
					if (AlphabeticallistofproductsData.UnitsOnOrder != 0)
						sbFilterExpression.AppendFormat("UnitsOnOrder = {0} AND ", AlphabeticallistofproductsData.UnitsOnOrder);
		
					if (AlphabeticallistofproductsData.ReorderLevel != 0)
						sbFilterExpression.AppendFormat("ReorderLevel = {0} AND ", AlphabeticallistofproductsData.ReorderLevel);
		
					if (AlphabeticallistofproductsData.Discontinued)
						sbFilterExpression.AppendFormat("Discontinued = '{0}' AND ", (AlphabeticallistofproductsData.Discontinued == true? 1 : 0).ToString());
		
					if (AlphabeticallistofproductsData.CategoryName != string.Empty)
						sbFilterExpression.AppendFormat("CategoryName like '%{0}%' AND ", AlphabeticallistofproductsData.CategoryName);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					AlphabeticallistofproductsData = null;
					AlphabeticallistofproductsData = new AlphabeticallistofproductsData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return AlphabeticallistofproductsData.IsValid;
			}
		}
    }
}
