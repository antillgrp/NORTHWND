/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for OrderDetailsExtended
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrderDetailsExtendedSearchViewModel : ViewModelBase
	{
		#region Private Members
		private OrderDetailsExtendedData _OrderDetailsExtendedData;
		private string _filterExpression;
		private OrderDetailsExtendedListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public OrderDetailsExtendedData OrderDetailsExtendedData
		{
			get
			{
				return _OrderDetailsExtendedData;
			}
			set
			{
				_OrderDetailsExtendedData = value;
				OnPropertyChanged("OrderDetailsExtendedData");
			}
		}
		public OrderDetailsExtendedListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public OrderDetailsExtendedSearchViewModel()
        {
            try
            {
				this.OrderDetailsExtendedData = new OrderDetailsExtendedData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (OrderDetailsExtendedData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", OrderDetailsExtendedData.OrderID);
		
					if (OrderDetailsExtendedData.ProductID != 0)
						sbFilterExpression.AppendFormat("ProductID = {0} AND ", OrderDetailsExtendedData.ProductID);
		
					if (OrderDetailsExtendedData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", OrderDetailsExtendedData.ProductName);
		
					if (OrderDetailsExtendedData.UnitPrice != 0)
						sbFilterExpression.AppendFormat("UnitPrice = {0} AND ", OrderDetailsExtendedData.UnitPrice);
		
					if (OrderDetailsExtendedData.Quantity != 0)
						sbFilterExpression.AppendFormat("Quantity = {0} AND ", OrderDetailsExtendedData.Quantity);
		
					if (OrderDetailsExtendedData.ExtendedPrice != 0)
						sbFilterExpression.AppendFormat("ExtendedPrice = {0} AND ", OrderDetailsExtendedData.ExtendedPrice);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					OrderDetailsExtendedData = null;
					OrderDetailsExtendedData = new OrderDetailsExtendedData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return OrderDetailsExtendedData.IsValid;
			}
		}
    }
}
