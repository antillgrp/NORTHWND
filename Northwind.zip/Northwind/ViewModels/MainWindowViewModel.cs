using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;
using System.Diagnostics;

namespace Northwind.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        private ViewModelBase _currentViewModel;
        public ViewModelBase CurrentViewModel
        {
            get { return _currentViewModel; }
            set
            {
                _currentViewModel = value;
                OnPropertyChanged("CurrentViewModel");
            }
        }

        public ICommand NavigateCommand { get; set; }

        public MainWindowViewModel()
        {
			Dictionary<string, Func<ViewModelBase>> viewModelList = new Dictionary<string, Func<ViewModelBase>>();
			viewModelList.Add("Home", () => new HomePageViewModel());
			viewModelList.Add("AppSettings", () => { return new AppSettingsListViewModel(); });
			viewModelList.Add("Categories", () => { return new CategoriesListViewModel(); });
			viewModelList.Add("CustomerCustomerDemo", () => { return new CustomerCustomerDemoListViewModel(); });
			viewModelList.Add("CustomerDemographics", () => { return new CustomerDemographicsListViewModel(); });
			viewModelList.Add("Customers", () => { return new CustomersListViewModel(); });
			viewModelList.Add("Employees", () => { return new EmployeesListViewModel(); });
			viewModelList.Add("EmployeeTerritories", () => { return new EmployeeTerritoriesListViewModel(); });
			viewModelList.Add("OrderDetails", () => { return new OrderDetailsListViewModel(); });
			viewModelList.Add("Orders", () => { return new OrdersListViewModel(); });
			viewModelList.Add("Products", () => { return new ProductsListViewModel(); });
			viewModelList.Add("Region", () => { return new RegionListViewModel(); });
			viewModelList.Add("Shippers", () => { return new ShippersListViewModel(); });
			viewModelList.Add("Suppliers", () => { return new SuppliersListViewModel(); });
			viewModelList.Add("Territories", () => { return new TerritoriesListViewModel(); });
			viewModelList.Add("Alphabeticallistofproducts", () => { return new AlphabeticallistofproductsListViewModel(); });
			viewModelList.Add("CategorySalesfor1997", () => { return new CategorySalesfor1997ListViewModel(); });
			viewModelList.Add("CurrentProductList", () => { return new CurrentProductListListViewModel(); });
			viewModelList.Add("CustomerandSuppliersbyCity", () => { return new CustomerandSuppliersbyCityListViewModel(); });
			viewModelList.Add("Invoices", () => { return new InvoicesListViewModel(); });
			viewModelList.Add("OrderDetailsExtended", () => { return new OrderDetailsExtendedListViewModel(); });
			viewModelList.Add("OrderSubtotals", () => { return new OrderSubtotalsListViewModel(); });
			viewModelList.Add("OrdersQry", () => { return new OrdersQryListViewModel(); });
			viewModelList.Add("ProductSalesfor1997", () => { return new ProductSalesfor1997ListViewModel(); });
			viewModelList.Add("ProductsAboveAveragePrice", () => { return new ProductsAboveAveragePriceListViewModel(); });
			viewModelList.Add("ProductsbyCategory", () => { return new ProductsbyCategoryListViewModel(); });
			viewModelList.Add("QuarterlyOrders", () => { return new QuarterlyOrdersListViewModel(); });
			viewModelList.Add("SalesbyCategory", () => { return new SalesbyCategoryListViewModel(); });
			viewModelList.Add("SalesTotalsbyAmount", () => { return new SalesTotalsbyAmountListViewModel(); });
			viewModelList.Add("SummaryofSalesbyQuarter", () => { return new SummaryofSalesbyQuarterListViewModel(); });
			viewModelList.Add("SummaryofSalesbyYear", () => { return new SummaryofSalesbyYearListViewModel(); });


			// Invoke HomePageViewModel
			this.CurrentViewModel = new HomePageViewModel();
			this.CurrentViewModel.ParentWindowViewModel = this;

			this.NavigateCommand=new RelayCommand((e) =>
            {
				if (e != null)
				{
					if (e.ToString().Equals("ContactUs"))
					{
						Process.Start("http://www.codebhagat.com/Support/ContactUs.aspx");
						return;
					}
					else if (e.ToString().Equals("About"))
					{
						Process.Start("http://www.codebhagat.com/Support/About.aspx");
						return;
					}
				}
			if (e != null && viewModelList.ContainsKey(e.ToString()))
			{
				this.CurrentViewModel = viewModelList[e.ToString()]();
				this.CurrentViewModel.ParentWindowViewModel = this;
			}
            });
        }
    }
}
