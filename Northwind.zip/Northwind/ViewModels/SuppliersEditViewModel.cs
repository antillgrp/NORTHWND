/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Suppliers table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class SuppliersEditViewModel : ViewModelBase
    {
        private SuppliersData _SuppliersData;
        public SuppliersData SuppliersData
        {
            get { return _SuppliersData; }
            set
            {
                _SuppliersData = value;
                OnPropertyChanged("SuppliersData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public SuppliersEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new SuppliersListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Suppliers.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Suppliers.");

                    if (SuppliersData != null)
                    {
                        var SuppliersDetail = Suppliers.GetDetails(SuppliersData.SupplierID.ToString());
                        bool saveResult;
                        if (SuppliersDetail != null && SuppliersDetail.Tables.Count > 0 && SuppliersDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Suppliers.Update(SuppliersData);
                        }
                        else
                        {
                            saveResult = Suppliers.Add(SuppliersData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new SuppliersListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Suppliers?");
					if (result == MessageBoxResult.Yes)
					{
						var objSuppliers = p as SuppliersData;
						if (objSuppliers != null)
						{
							if (Suppliers.Delete(objSuppliers.SupplierID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Suppliers {0}  successfully!", objSuppliers.SupplierID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new SuppliersListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Suppliers {0}  fails!", objSuppliers.SupplierID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_SuppliersData != null)
					return SuppliersData.IsValid;
				else
					return false;
				
			}
		}

    }
}
