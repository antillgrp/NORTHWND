/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for OrderDetails table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrderDetailsDetailViewModel : ViewModelBase
    {
        private OrderDetailsData _OrderDetailsData;
        public OrderDetailsData OrderDetailsData
        {
            get
            {
                return _OrderDetailsData;
            }
            set
            {
                _OrderDetailsData = value;
                OnPropertyChanged("OrderDetailsData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public OrderDetailsDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new OrderDetailsListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new OrderDetailsEditViewModel() { ParentWindowViewModel = parent, OrderDetailsData = this.OrderDetailsData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this OrderDetails?");
					if (result == MessageBoxResult.Yes)
					{
						var objOrderDetails = p as OrderDetailsData;
						if (objOrderDetails != null)
						{
							if (OrderDetails.Delete(objOrderDetails.OrderID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete OrderDetails {0}  successfully!", objOrderDetails.OrderID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new OrderDetailsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete OrderDetails {0}  fails!", objOrderDetails.OrderID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
