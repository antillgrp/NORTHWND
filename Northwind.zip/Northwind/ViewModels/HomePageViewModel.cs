using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;
using System.Diagnostics;

namespace Northwind.ViewModels
{
    public class HomePageViewModel : ViewModelBase
    {
        private ViewModelBase _currentViewModel;
        public ViewModelBase CurrentViewModel
        {
            get { return _currentViewModel; }
            set
            {
                _currentViewModel = value;
                OnPropertyChanged("CurrentViewModel");
            }
        }

        public ICommand NavigateCommand { get; set; }
		public HomePageViewModel()
        {
			Dictionary<string, string> cmdList = new Dictionary<string, string>();
			cmdList.Add("Home", "http://www.codebhagat.com");
			cmdList.Add("Tutorial", "http://www.codebhagat.com/Tutorials/WPFMVVMApp.aspx");
			cmdList.Add("Download", "http://www.codebhagat.com/Samples/Default.aspx");
			this.NavigateCommand = new RelayCommand((e) =>
			{
				if (e != null && cmdList.ContainsKey(e.ToString()))
				{
					Process.Start(cmdList[e.ToString()]);
				}
			});
        }
    }
}
