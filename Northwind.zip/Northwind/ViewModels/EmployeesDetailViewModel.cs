/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Employees table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class EmployeesDetailViewModel : ViewModelBase
    {
        private EmployeesData _EmployeesData;
        public EmployeesData EmployeesData
        {
            get
            {
                return _EmployeesData;
            }
            set
            {
                _EmployeesData = value;
                OnPropertyChanged("EmployeesData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public EmployeesDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new EmployeesListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new EmployeesEditViewModel() { ParentWindowViewModel = parent, EmployeesData = this.EmployeesData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Employees?");
					if (result == MessageBoxResult.Yes)
					{
						var objEmployees = p as EmployeesData;
						if (objEmployees != null)
						{
							if (Employees.Delete(objEmployees.EmployeeID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Employees {0}  successfully!", objEmployees.EmployeeID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new EmployeesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete Employees {0}  fails!", objEmployees.EmployeeID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
