/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Categories table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class CategoriesEditViewModel : ViewModelBase
    {
        private CategoriesData _CategoriesData;
        public CategoriesData CategoriesData
        {
            get { return _CategoriesData; }
            set
            {
                _CategoriesData = value;
                OnPropertyChanged("CategoriesData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public CategoriesEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CategoriesListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Categories.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Categories.");

                    if (CategoriesData != null)
                    {
                        var CategoriesDetail = Categories.GetDetails(CategoriesData.CategoryID.ToString());
                        bool saveResult;
                        if (CategoriesDetail != null && CategoriesDetail.Tables.Count > 0 && CategoriesDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Categories.Update(CategoriesData);
                        }
                        else
                        {
                            saveResult = Categories.Add(CategoriesData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new CategoriesListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Categories?");
					if (result == MessageBoxResult.Yes)
					{
						var objCategories = p as CategoriesData;
						if (objCategories != null)
						{
							if (Categories.Delete(objCategories.CategoryID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Categories {0}  successfully!", objCategories.CategoryID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new CategoriesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Categories {0}  fails!", objCategories.CategoryID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_CategoriesData != null)
					return CategoriesData.IsValid;
				else
					return false;
				
			}
		}

    }
}
