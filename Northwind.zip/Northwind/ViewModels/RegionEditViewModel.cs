/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Region table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class RegionEditViewModel : ViewModelBase
    {
        private RegionData _RegionData;
        public RegionData RegionData
        {
            get { return _RegionData; }
            set
            {
                _RegionData = value;
                OnPropertyChanged("RegionData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public RegionEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new RegionListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Region.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Region.");

                    if (RegionData != null)
                    {
                        var RegionDetail = Region.GetDetails(RegionData.RegionID.ToString());
                        bool saveResult;
                        if (RegionDetail != null && RegionDetail.Tables.Count > 0 && RegionDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Region.Update(RegionData);
                        }
                        else
                        {
                            saveResult = Region.Add(RegionData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new RegionListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Region?");
					if (result == MessageBoxResult.Yes)
					{
						var objRegion = p as RegionData;
						if (objRegion != null)
						{
							if (Region.Delete(objRegion.RegionID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Region {0}  successfully!", objRegion.RegionID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new RegionListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Region {0}  fails!", objRegion.RegionID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_RegionData != null)
					return RegionData.IsValid;
				else
					return false;
				
			}
		}

    }
}
