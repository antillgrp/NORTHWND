/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CustomerandSuppliersbyCity
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CustomerandSuppliersbyCitySearchViewModel : ViewModelBase
	{
		#region Private Members
		private CustomerandSuppliersbyCityData _CustomerandSuppliersbyCityData;
		private string _filterExpression;
		private CustomerandSuppliersbyCityListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public CustomerandSuppliersbyCityData CustomerandSuppliersbyCityData
		{
			get
			{
				return _CustomerandSuppliersbyCityData;
			}
			set
			{
				_CustomerandSuppliersbyCityData = value;
				OnPropertyChanged("CustomerandSuppliersbyCityData");
			}
		}
		public CustomerandSuppliersbyCityListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public CustomerandSuppliersbyCitySearchViewModel()
        {
            try
            {
				this.CustomerandSuppliersbyCityData = new CustomerandSuppliersbyCityData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (CustomerandSuppliersbyCityData.City != string.Empty)
						sbFilterExpression.AppendFormat("City like '%{0}%' AND ", CustomerandSuppliersbyCityData.City);
		
					if (CustomerandSuppliersbyCityData.CompanyName != string.Empty)
						sbFilterExpression.AppendFormat("CompanyName like '%{0}%' AND ", CustomerandSuppliersbyCityData.CompanyName);
		
					if (CustomerandSuppliersbyCityData.ContactName != string.Empty)
						sbFilterExpression.AppendFormat("ContactName like '%{0}%' AND ", CustomerandSuppliersbyCityData.ContactName);
		
					if (CustomerandSuppliersbyCityData.Relationship != string.Empty)
						sbFilterExpression.AppendFormat("Relationship like '%{0}%' AND ", CustomerandSuppliersbyCityData.Relationship);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					CustomerandSuppliersbyCityData = null;
					CustomerandSuppliersbyCityData = new CustomerandSuppliersbyCityData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return CustomerandSuppliersbyCityData.IsValid;
			}
		}
    }
}
