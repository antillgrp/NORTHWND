/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CustomerDemographics table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class CustomerDemographicsEditViewModel : ViewModelBase
    {
        private CustomerDemographicsData _CustomerDemographicsData;
        public CustomerDemographicsData CustomerDemographicsData
        {
            get { return _CustomerDemographicsData; }
            set
            {
                _CustomerDemographicsData = value;
                OnPropertyChanged("CustomerDemographicsData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public CustomerDemographicsEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CustomerDemographicsListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!CustomerDemographics.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid CustomerDemographics.");

                    if (CustomerDemographicsData != null)
                    {
                        var CustomerDemographicsDetail = CustomerDemographics.GetDetails(CustomerDemographicsData.CustomerTypeID.ToString());
                        bool saveResult;
                        if (CustomerDemographicsDetail != null && CustomerDemographicsDetail.Tables.Count > 0 && CustomerDemographicsDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = CustomerDemographics.Update(CustomerDemographicsData);
                        }
                        else
                        {
                            saveResult = CustomerDemographics.Add(CustomerDemographicsData) != string.Empty;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new CustomerDemographicsListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this CustomerDemographics?");
					if (result == MessageBoxResult.Yes)
					{
						var objCustomerDemographics = p as CustomerDemographicsData;
						if (objCustomerDemographics != null)
						{
							if (CustomerDemographics.Delete(objCustomerDemographics.CustomerTypeID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete CustomerDemographics {0}  successfully!", objCustomerDemographics.CustomerTypeID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new CustomerDemographicsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete CustomerDemographics {0}  fails!", objCustomerDemographics.CustomerTypeID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_CustomerDemographicsData != null)
					return CustomerDemographicsData.IsValid;
				else
					return false;
				
			}
		}

    }
}
