/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CategorySalesfor1997 view
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CategorySalesfor1997ListViewModel : ViewModelBase
	{
		#region Private Members
        private int _currentPageSize;
        private int _currentPage = 1;
        private int _totalPage = 1;
        private int _currentStart;
        private int _currentEnd;
        private int _totalCount;
		private string _filterExpression;

		private ObservableCollection<CategorySalesfor1997Data> _CategorySalesfor1997List;
		private CategorySalesfor1997SearchViewModel _CategorySalesfor1997SearchViewModel;
		#endregion

		#region Page Properties
		public ObservableCollection<CategorySalesfor1997Data> CategorySalesfor1997List
        {
            get { return _CategorySalesfor1997List; }
            set
            {
                _CategorySalesfor1997List = value;
                OnPropertyChanged("CategorySalesfor1997List");
            }
        }

		public CategorySalesfor1997Data SelectedCategorySalesfor1997;

		private int _selectedRowIndex = -1;
		public int SelectedRowIndex
		{
			get { return _selectedRowIndex; }
			set
			{
				_selectedRowIndex = value;
				if (CategorySalesfor1997List != null && CategorySalesfor1997List.Any() && _selectedRowIndex != -1)
				{
					SelectedCategorySalesfor1997 = CategorySalesfor1997List[_selectedRowIndex];
				}
				OnPropertyChanged("CategorySalesfor1997List");
				OnPropertyChanged("SelectedRowIndex");
			}
		}
		
		public CategorySalesfor1997SearchViewModel CategorySalesfor1997SearchViewModel
		{
			get { return _CategorySalesfor1997SearchViewModel; }
			set
			{
				_CategorySalesfor1997SearchViewModel = value;
				OnPropertyChanged("CategorySalesfor1997SearchViewModel");
				OnPropertyChanged("FilterExpression");
			}
		}
		
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				OnPropertyChanged("FilterExpression");
				this.GetData();
			}
		}
		


        #region For Paging
        public List<int> PageSizeList { get; set; }
        public int CurrentPageSize
        {
            get { return _currentPageSize; }
            set
            {
                _currentPageSize = value;
                OnPropertyChanged("CurrentPageSize");
                OnPropertyChanged("TotalPage");
                OnPropertyChanged("CurrentStart");
                OnPropertyChanged("CurrentEnd");
				CurrentPage = 1;
				this.GetData();
                //todo redo search and display
            }
        }

        public int CurrentPage
        {
            get { return _currentPage; }
            set
            {
                _currentPage = value;
                OnPropertyChanged("CurrentPage");
            }
        }

        public int TotalPage
        {
            get
            {
                if (this.CurrentPageSize > 0)
                {
                    _totalPage = (this.TotalCount + this.CurrentPageSize -1) / this.CurrentPageSize;
                }
                else
                {
                    _totalPage = 0;
                }
                return _totalPage;
            }
        }

        public int CurrentStart
        {
            get
            {
                if (CurrentPage > 0)
                {
                    _currentStart = CurrentPageSize * (CurrentPage - 1) + 1;
                }
                return _currentStart;
            }
        }

        public int CurrentEnd
        {
            get
            {
                _currentEnd = this.CurrentPage * this.CurrentPageSize;
                if (_currentEnd > TotalCount)
                {
                    _currentEnd = TotalCount;
                }
                return _currentEnd;
            }
        }

        public int TotalCount
        {
            get { return _totalCount; }
            set
            {
                _totalCount = value;
                OnPropertyChanged("TotalCount");
                OnPropertyChanged("TotalPage");
                OnPropertyChanged("CurrentStart");
                OnPropertyChanged("CurrentEnd");
            }
        }
        #endregion

        #endregion

        #region Commands Definition
		// Search Commands
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }

		// Paging Commands
        public ICommand CommFirst { get; set; }
        public ICommand CommPrev { get; set; }
        public ICommand CommNext { get; set; }
        public ICommand CommLast { get; set; }

		// Action Commands
        public ICommand AddNewCommand { get; set; }
        public ICommand RefreshCommand { get; set; }
        public ICommand DeleteListCommand { get; set; }

        // Row Action Commands
        public ICommand EditCommand { get; set; }
        public ICommand ViewCommand { get; set; }
		public ICommand DeleteCommand { get; set; }
		#endregion

		#region Page View Model
		public CategorySalesfor1997ListViewModel()
        {
            this.PageSizeList = new List<int>()
            {
                10, 25, 50, 100
            };
            this.CurrentPageSize = this.PageSizeList[0];

            try
            {
                this.GetData();



				this._CategorySalesfor1997SearchViewModel = new CategorySalesfor1997SearchViewModel();
				this._CategorySalesfor1997SearchViewModel.ParentViewModel = this;

				// Goto First Page
                this.CommFirst = new RelayCommand((p) =>
                {
                    this.CurrentPage = 1;
                    this.GetData();
                });
				// Goto Previous Page
                this.CommPrev = new RelayCommand((p) =>
                {
                    if (this.CurrentPage > 1)
                    {
                        this.CurrentPage--;
                    }
                    this.GetData();
                }, (e) => this.CurrentPage != 1);

				// Goto Next Page
                this.CommNext = new RelayCommand((p) =>
                {
                    if (this.CurrentPage < TotalPage)
                    {
                        this.CurrentPage++;
                    }
                    this.GetData();

                }, (e) => this.CurrentPage != TotalPage);

				// Goto Last Page
                this.CommLast = new RelayCommand((p) =>
                {
                    if (this.CurrentPage < TotalPage)
                    {
                        this.CurrentPage = TotalPage;
                    }
                    this.GetData();
                }, (e) => this.CurrentPage != TotalPage);

				// VIEW Selected Record
				this.ViewCommand = new RelayCommand((p) =>
				{
					var parent = this.ParentWindowViewModel as MainWindowViewModel;
					if (parent != null)
					{
						parent.CurrentViewModel = new CategorySalesfor1997DetailViewModel() { ParentWindowViewModel = parent, CategorySalesfor1997Data = SelectedCategorySalesfor1997 as CategorySalesfor1997Data };
					}
				});
				// REFRESH Data
                this.RefreshCommand = new RelayCommand((p) =>
                {
                    this.GetData();
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		/// <summary>
        /// Refresh the CategorySalesfor1997 data
        /// </summary>
        public void GetData()
        {
			int total = 0;
			List<CategorySalesfor1997Data> objCategorySalesfor1997DataList = CategorySalesfor1997.GetList(FilterExpression, "CategoryName", this.CurrentPage, this.CurrentPageSize, out total);
			this.CategorySalesfor1997List = new ObservableCollection<CategorySalesfor1997Data>(objCategorySalesfor1997DataList);
			this.TotalCount = total;
		}
    }
}
