/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Products table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class ProductsDetailViewModel : ViewModelBase
    {
        private ProductsData _ProductsData;
        public ProductsData ProductsData
        {
            get
            {
                return _ProductsData;
            }
            set
            {
                _ProductsData = value;
                OnPropertyChanged("ProductsData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public ProductsDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new ProductsListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new ProductsEditViewModel() { ParentWindowViewModel = parent, ProductsData = this.ProductsData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Products?");
					if (result == MessageBoxResult.Yes)
					{
						var objProducts = p as ProductsData;
						if (objProducts != null)
						{
							if (Products.Delete(objProducts.ProductID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Products {0}  successfully!", objProducts.ProductID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new ProductsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete Products {0}  fails!", objProducts.ProductID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
