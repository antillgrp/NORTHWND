/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Products table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class ProductsEditViewModel : ViewModelBase
    {
        private ProductsData _ProductsData;
        public ProductsData ProductsData
        {
            get { return _ProductsData; }
            set
            {
                _ProductsData = value;
                OnPropertyChanged("ProductsData");
            }
        }

		public List<SuppliersData> SuppliersList { get; set; }
		private int _selectedSupplierIDIndex;
		public int SelectedSupplierIDIndex
		{
			get { return _selectedSupplierIDIndex; }
			set
			{
				_selectedSupplierIDIndex = (value < 0 ? 0 : value);

				if (ProductsData != null && SuppliersList != null && SuppliersList.Any())
				{
					ProductsData.SupplierID = SuppliersList[_selectedSupplierIDIndex].SupplierID;
				}
				OnPropertyChanged("ProductsData");
				OnPropertyChanged("SelectedSupplierIDIndex");

			}
		}
		public List<CategoriesData> CategoriesList { get; set; }
		private int _selectedCategoryIDIndex;
		public int SelectedCategoryIDIndex
		{
			get { return _selectedCategoryIDIndex; }
			set
			{
				_selectedCategoryIDIndex = (value < 0 ? 0 : value);

				if (ProductsData != null && CategoriesList != null && CategoriesList.Any())
				{
					ProductsData.CategoryID = CategoriesList[_selectedCategoryIDIndex].CategoryID;
				}
				OnPropertyChanged("ProductsData");
				OnPropertyChanged("SelectedCategoryIDIndex");

			}
		}

        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ProductsEditViewModel()
        {
            try
            {
                this.SuppliersList = Suppliers.GetList("");
				this.SuppliersList.Insert(0, new SuppliersData() { SupplierID = 0, CompanyName = "SELECT" });
                this.CategoriesList = Categories.GetList("");
				this.CategoriesList.Insert(0, new CategoriesData() { CategoryID = 0, CategoryName = "SELECT" });

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new ProductsListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Products.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Products.");

                    if (ProductsData != null)
                    {
                        var ProductsDetail = Products.GetDetails(ProductsData.ProductID.ToString());
                        bool saveResult;
                        if (ProductsDetail != null && ProductsDetail.Tables.Count > 0 && ProductsDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Products.Update(ProductsData);
                        }
                        else
                        {
                            saveResult = Products.Add(ProductsData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new ProductsListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Products?");
					if (result == MessageBoxResult.Yes)
					{
						var objProducts = p as ProductsData;
						if (objProducts != null)
						{
							if (Products.Delete(objProducts.ProductID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Products {0}  successfully!", objProducts.ProductID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new ProductsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Products {0}  fails!", objProducts.ProductID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_ProductsData != null)
					return ProductsData.IsValid;
				else
					return false;
				
			}
		}

    }
}
