/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for CustomerDemographics table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CustomerDemographicsDetailViewModel : ViewModelBase
    {
        private CustomerDemographicsData _CustomerDemographicsData;
        public CustomerDemographicsData CustomerDemographicsData
        {
            get
            {
                return _CustomerDemographicsData;
            }
            set
            {
                _CustomerDemographicsData = value;
                OnPropertyChanged("CustomerDemographicsData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public CustomerDemographicsDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CustomerDemographicsListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CustomerDemographicsEditViewModel() { ParentWindowViewModel = parent, CustomerDemographicsData = this.CustomerDemographicsData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this CustomerDemographics?");
					if (result == MessageBoxResult.Yes)
					{
						var objCustomerDemographics = p as CustomerDemographicsData;
						if (objCustomerDemographics != null)
						{
							if (CustomerDemographics.Delete(objCustomerDemographics.CustomerTypeID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete CustomerDemographics {0}  successfully!", objCustomerDemographics.CustomerTypeID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new CustomerDemographicsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete CustomerDemographics {0}  fails!", objCustomerDemographics.CustomerTypeID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
