/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for AppSettings
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class AppSettingsSearchViewModel : ViewModelBase
	{
		#region Private Members
		private AppSettingsData _AppSettingsData;
		private string _filterExpression;
		private AppSettingsListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public AppSettingsData AppSettingsData
		{
			get
			{
				return _AppSettingsData;
			}
			set
			{
				_AppSettingsData = value;
				OnPropertyChanged("AppSettingsData");
			}
		}
		public AppSettingsListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public AppSettingsSearchViewModel()
        {
            try
            {
				this.AppSettingsData = new AppSettingsData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (AppSettingsData.OptionID != 0)
						sbFilterExpression.AppendFormat("OptionID = {0} AND ", AppSettingsData.OptionID);
		
					if (AppSettingsData.KeyName != string.Empty)
						sbFilterExpression.AppendFormat("KeyName like '%{0}%' AND ", AppSettingsData.KeyName);
		
					if (AppSettingsData.KeyValue != string.Empty)
						sbFilterExpression.AppendFormat("KeyValue like '%{0}%' AND ", AppSettingsData.KeyValue);
		
					if (AppSettingsData.Comments != string.Empty)
						sbFilterExpression.AppendFormat("Comments like '%{0}%' AND ", AppSettingsData.Comments);
		
					if (AppSettingsData.CreatedDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("CreatedDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(AppSettingsData.CreatedDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(AppSettingsData.CreatedDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (AppSettingsData.UpdatedDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("UpdatedDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(AppSettingsData.UpdatedDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(AppSettingsData.UpdatedDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					AppSettingsData = null;
					AppSettingsData = new AppSettingsData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return AppSettingsData.IsValid;
			}
		}
    }
}
