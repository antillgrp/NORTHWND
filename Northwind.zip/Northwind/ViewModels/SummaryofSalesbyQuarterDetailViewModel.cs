/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for SummaryofSalesbyQuarter view
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class SummaryofSalesbyQuarterDetailViewModel : ViewModelBase
    {
        private SummaryofSalesbyQuarterData _SummaryofSalesbyQuarterData;
        public SummaryofSalesbyQuarterData SummaryofSalesbyQuarterData
        {
            get
            {
                return _SummaryofSalesbyQuarterData;
            }
            set
            {
                _SummaryofSalesbyQuarterData = value;
                OnPropertyChanged("SummaryofSalesbyQuarterData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public SummaryofSalesbyQuarterDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new SummaryofSalesbyQuarterListViewModel() { ParentWindowViewModel = parent };
                    }
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
