using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Northwind.ViewModels
{
    public abstract class ViewModelBase : INotifyPropertyChanged, IDataErrorInfo
    {
        protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
        public ViewModelBase ParentWindowViewModel { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public string this[string columnName]
        {
            get
            {
                if (ErrorDictionary.ContainsKey(columnName))
                    return ErrorDictionary[columnName];
                else
                    return null;
            }
        }

        public string Error
        {
            get
            {
                if (ErrorDictionary != null && ErrorDictionary.Any())
                {
                    return ErrorDictionary.FirstOrDefault().Value;
                }
                return null;
            }
        }
    }
}
