/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Invoices
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class InvoicesSearchViewModel : ViewModelBase
	{
		#region Private Members
		private InvoicesData _InvoicesData;
		private string _filterExpression;
		private InvoicesListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public InvoicesData InvoicesData
		{
			get
			{
				return _InvoicesData;
			}
			set
			{
				_InvoicesData = value;
				OnPropertyChanged("InvoicesData");
			}
		}
		public InvoicesListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public InvoicesSearchViewModel()
        {
            try
            {
				this.InvoicesData = new InvoicesData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (InvoicesData.ShipName != string.Empty)
						sbFilterExpression.AppendFormat("ShipName like '%{0}%' AND ", InvoicesData.ShipName);
		
					if (InvoicesData.ShipAddress != string.Empty)
						sbFilterExpression.AppendFormat("ShipAddress like '%{0}%' AND ", InvoicesData.ShipAddress);
		
					if (InvoicesData.ShipCity != string.Empty)
						sbFilterExpression.AppendFormat("ShipCity like '%{0}%' AND ", InvoicesData.ShipCity);
		
					if (InvoicesData.ShipRegion != string.Empty)
						sbFilterExpression.AppendFormat("ShipRegion like '%{0}%' AND ", InvoicesData.ShipRegion);
		
					if (InvoicesData.ShipPostalCode != string.Empty)
						sbFilterExpression.AppendFormat("ShipPostalCode like '%{0}%' AND ", InvoicesData.ShipPostalCode);
		
					if (InvoicesData.ShipCountry != string.Empty)
						sbFilterExpression.AppendFormat("ShipCountry like '%{0}%' AND ", InvoicesData.ShipCountry);
		
					if (InvoicesData.CustomerID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerID like '%{0}%' AND ", InvoicesData.CustomerID);
		
					if (InvoicesData.CustomerName != string.Empty)
						sbFilterExpression.AppendFormat("CustomerName like '%{0}%' AND ", InvoicesData.CustomerName);
		
					if (InvoicesData.Address != string.Empty)
						sbFilterExpression.AppendFormat("Address like '%{0}%' AND ", InvoicesData.Address);
		
					if (InvoicesData.City != string.Empty)
						sbFilterExpression.AppendFormat("City like '%{0}%' AND ", InvoicesData.City);
		
					if (InvoicesData.Region != string.Empty)
						sbFilterExpression.AppendFormat("Region like '%{0}%' AND ", InvoicesData.Region);
		
					if (InvoicesData.PostalCode != string.Empty)
						sbFilterExpression.AppendFormat("PostalCode like '%{0}%' AND ", InvoicesData.PostalCode);
		
					if (InvoicesData.Country != string.Empty)
						sbFilterExpression.AppendFormat("Country like '%{0}%' AND ", InvoicesData.Country);
		
					if (InvoicesData.Salesperson != string.Empty)
						sbFilterExpression.AppendFormat("Salesperson like '%{0}%' AND ", InvoicesData.Salesperson);
		
					if (InvoicesData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", InvoicesData.OrderID);
		
					if (InvoicesData.OrderDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("OrderDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(InvoicesData.OrderDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(InvoicesData.OrderDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (InvoicesData.RequiredDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("RequiredDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(InvoicesData.RequiredDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(InvoicesData.RequiredDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (InvoicesData.ShippedDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("ShippedDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(InvoicesData.ShippedDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(InvoicesData.ShippedDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (InvoicesData.ShipperName != string.Empty)
						sbFilterExpression.AppendFormat("ShipperName like '%{0}%' AND ", InvoicesData.ShipperName);
		
					if (InvoicesData.ProductID != 0)
						sbFilterExpression.AppendFormat("ProductID = {0} AND ", InvoicesData.ProductID);
		
					if (InvoicesData.ProductName != string.Empty)
						sbFilterExpression.AppendFormat("ProductName like '%{0}%' AND ", InvoicesData.ProductName);
		
					if (InvoicesData.UnitPrice != 0)
						sbFilterExpression.AppendFormat("UnitPrice = {0} AND ", InvoicesData.UnitPrice);
		
					if (InvoicesData.Quantity != 0)
						sbFilterExpression.AppendFormat("Quantity = {0} AND ", InvoicesData.Quantity);
		
					if (InvoicesData.ExtendedPrice != 0)
						sbFilterExpression.AppendFormat("ExtendedPrice = {0} AND ", InvoicesData.ExtendedPrice);
		
					if (InvoicesData.Freight != 0)
						sbFilterExpression.AppendFormat("Freight = {0} AND ", InvoicesData.Freight);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					InvoicesData = null;
					InvoicesData = new InvoicesData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return InvoicesData.IsValid;
			}
		}
    }
}
