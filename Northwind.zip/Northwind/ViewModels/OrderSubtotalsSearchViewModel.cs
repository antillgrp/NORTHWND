/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for OrderSubtotals
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrderSubtotalsSearchViewModel : ViewModelBase
	{
		#region Private Members
		private OrderSubtotalsData _OrderSubtotalsData;
		private string _filterExpression;
		private OrderSubtotalsListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public OrderSubtotalsData OrderSubtotalsData
		{
			get
			{
				return _OrderSubtotalsData;
			}
			set
			{
				_OrderSubtotalsData = value;
				OnPropertyChanged("OrderSubtotalsData");
			}
		}
		public OrderSubtotalsListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public OrderSubtotalsSearchViewModel()
        {
            try
            {
				this.OrderSubtotalsData = new OrderSubtotalsData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (OrderSubtotalsData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", OrderSubtotalsData.OrderID);
		
					if (OrderSubtotalsData.Subtotal != 0)
						sbFilterExpression.AppendFormat("Subtotal = {0} AND ", OrderSubtotalsData.Subtotal);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					OrderSubtotalsData = null;
					OrderSubtotalsData = new OrderSubtotalsData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return OrderSubtotalsData.IsValid;
			}
		}
    }
}
