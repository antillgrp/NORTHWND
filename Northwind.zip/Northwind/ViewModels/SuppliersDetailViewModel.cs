/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Suppliers table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class SuppliersDetailViewModel : ViewModelBase
    {
        private SuppliersData _SuppliersData;
        public SuppliersData SuppliersData
        {
            get
            {
                return _SuppliersData;
            }
            set
            {
                _SuppliersData = value;
                OnPropertyChanged("SuppliersData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public SuppliersDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new SuppliersListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new SuppliersEditViewModel() { ParentWindowViewModel = parent, SuppliersData = this.SuppliersData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Suppliers?");
					if (result == MessageBoxResult.Yes)
					{
						var objSuppliers = p as SuppliersData;
						if (objSuppliers != null)
						{
							if (Suppliers.Delete(objSuppliers.SupplierID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Suppliers {0}  successfully!", objSuppliers.SupplierID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new SuppliersListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete Suppliers {0}  fails!", objSuppliers.SupplierID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
