/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Categories
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CategoriesSearchViewModel : ViewModelBase
	{
		#region Private Members
		private CategoriesData _CategoriesData;
		private string _filterExpression;
		private CategoriesListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public CategoriesData CategoriesData
		{
			get
			{
				return _CategoriesData;
			}
			set
			{
				_CategoriesData = value;
				OnPropertyChanged("CategoriesData");
			}
		}
		public CategoriesListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public CategoriesSearchViewModel()
        {
            try
            {
				this.CategoriesData = new CategoriesData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (CategoriesData.CategoryID != 0)
						sbFilterExpression.AppendFormat("CategoryID = {0} AND ", CategoriesData.CategoryID);
		
					if (CategoriesData.CategoryName != string.Empty)
						sbFilterExpression.AppendFormat("CategoryName like '%{0}%' AND ", CategoriesData.CategoryName);
		
					if (CategoriesData.Description != string.Empty)
						sbFilterExpression.AppendFormat("Description like '%{0}%' AND ", CategoriesData.Description);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					CategoriesData = null;
					CategoriesData = new CategoriesData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return CategoriesData.IsValid;
			}
		}
    }
}
