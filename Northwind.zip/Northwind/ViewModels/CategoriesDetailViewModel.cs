/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Categories table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class CategoriesDetailViewModel : ViewModelBase
    {
        private CategoriesData _CategoriesData;
        public CategoriesData CategoriesData
        {
            get
            {
                return _CategoriesData;
            }
            set
            {
                _CategoriesData = value;
                OnPropertyChanged("CategoriesData");
            }
        }

		// Commands
        public ICommand GoBackCommand { get; set; }
        public ICommand EditCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public CategoriesDetailViewModel()
        {
            try
            {
				// BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CategoriesListViewModel() { ParentWindowViewModel = parent };
                    }
                });
				// EDIT
                this.EditCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new CategoriesEditViewModel() { ParentWindowViewModel = parent, CategoriesData = this.CategoriesData };
                    }
                });
				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Categories?");
					if (result == MessageBoxResult.Yes)
					{
						var objCategories = p as CategoriesData;
						if (objCategories != null)
						{
							if (Categories.Delete(objCategories.CategoryID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Categories {0}  successfully!", objCategories.CategoryID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new CategoriesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("Delete Categories {0}  fails!", objCategories.CategoryID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
    }
}
