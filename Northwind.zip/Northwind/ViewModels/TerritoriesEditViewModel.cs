/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Territories table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class TerritoriesEditViewModel : ViewModelBase
    {
        private TerritoriesData _TerritoriesData;
        public TerritoriesData TerritoriesData
        {
            get { return _TerritoriesData; }
            set
            {
                _TerritoriesData = value;
                OnPropertyChanged("TerritoriesData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public TerritoriesEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new TerritoriesListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!Territories.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid Territories.");

                    if (TerritoriesData != null)
                    {
                        var TerritoriesDetail = Territories.GetDetails(TerritoriesData.TerritoryID.ToString());
                        bool saveResult;
                        if (TerritoriesDetail != null && TerritoriesDetail.Tables.Count > 0 && TerritoriesDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = Territories.Update(TerritoriesData);
                        }
                        else
                        {
                            saveResult = Territories.Add(TerritoriesData) != string.Empty;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new TerritoriesListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this Territories?");
					if (result == MessageBoxResult.Yes)
					{
						var objTerritories = p as TerritoriesData;
						if (objTerritories != null)
						{
							if (Territories.Delete(objTerritories.TerritoryID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete Territories {0}  successfully!", objTerritories.TerritoryID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new TerritoriesListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete Territories {0}  fails!", objTerritories.TerritoryID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_TerritoriesData != null)
					return TerritoriesData.IsValid;
				else
					return false;
				
			}
		}

    }
}
