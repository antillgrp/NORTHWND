/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Region
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class RegionSearchViewModel : ViewModelBase
	{
		#region Private Members
		private RegionData _RegionData;
		private string _filterExpression;
		private RegionListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public RegionData RegionData
		{
			get
			{
				return _RegionData;
			}
			set
			{
				_RegionData = value;
				OnPropertyChanged("RegionData");
			}
		}
		public RegionListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public RegionSearchViewModel()
        {
            try
            {
				this.RegionData = new RegionData();

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (RegionData.RegionID != 0)
						sbFilterExpression.AppendFormat("RegionID = {0} AND ", RegionData.RegionID);
		
					if (RegionData.RegionDescription != string.Empty)
						sbFilterExpression.AppendFormat("RegionDescription like '%{0}%' AND ", RegionData.RegionDescription);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					RegionData = null;
					RegionData = new RegionData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return RegionData.IsValid;
			}
		}
    }
}
