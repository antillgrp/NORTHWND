/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for AppSettings table
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
	public class AppSettingsEditViewModel : ViewModelBase
    {
        private AppSettingsData _AppSettingsData;
        public AppSettingsData AppSettingsData
        {
            get { return _AppSettingsData; }
            set
            {
                _AppSettingsData = value;
                OnPropertyChanged("AppSettingsData");
            }
        }


        public ICommand GoBackCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public AppSettingsEditViewModel()
        {
            try
            {

                // BACK
                this.GoBackCommand = new RelayCommand((p) =>
                {
                    var parent = ParentWindowViewModel as MainWindowViewModel;
                    if (parent != null)
                    {
                        parent.CurrentViewModel = new AppSettingsListViewModel() { ParentWindowViewModel = parent };
                    }
                });

				// SAVE
                this.SaveCommand = new RelayCommand((p) =>
                {
                    if (!string.IsNullOrEmpty(this.Error))
                    {
                        return;
                    }

					//if (!AppSettings.IsValid)
					//    throw new InvalidOperationException("Cannot save an invalid AppSettings.");

                    if (AppSettingsData != null)
                    {
                        var AppSettingsDetail = AppSettings.GetDetails(AppSettingsData.OptionID.ToString());
                        bool saveResult;
                        if (AppSettingsDetail != null && AppSettingsDetail.Tables.Count > 0 && AppSettingsDetail.Tables[0].Rows.Count > 0)  //exist then Update
                        {
                            saveResult = AppSettings.Update(AppSettingsData);
                        }
                        else
                        {
                            saveResult = AppSettings.Add(AppSettingsData) > 0;
                        }
                        if (saveResult) //todo add messagebox?
                        {
                            var parent = ParentWindowViewModel as MainWindowViewModel;
                            if (parent != null)
                            {
                                parent.CurrentViewModel = new AppSettingsListViewModel() { ParentWindowViewModel = parent };
                            }
                        }
                    }
				}, p => this.CanSave);

				// DELETE
                this.DeleteCommand = new RelayCommand((p) =>
                {
                    var result = MessageService.ShowMessageWithConfirm("Do you really want to delete this AppSettings?");
					if (result == MessageBoxResult.Yes)
					{
						var objAppSettings = p as AppSettingsData;
						if (objAppSettings != null)
						{
							if (AppSettings.Delete(objAppSettings.OptionID.ToString()))
							{
								MessageService.ShowMessage(string.Format("delete AppSettings {0}  successfully!", objAppSettings.OptionID));
								var parent = ParentWindowViewModel as MainWindowViewModel;
								if (parent != null)
								{
									parent.CurrentViewModel = new AppSettingsListViewModel() { ParentWindowViewModel = parent };
								}
							}
							else
							{
								MessageService.ShowMessage(string.Format("delete AppSettings {0}  fails!", objAppSettings.OptionID));
							}
						}
					}
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }

		bool CanSave
		{
			get 
			{
				if (_AppSettingsData != null)
					return AppSettingsData.IsValid;
				else
					return false;
				
			}
		}

    }
}
