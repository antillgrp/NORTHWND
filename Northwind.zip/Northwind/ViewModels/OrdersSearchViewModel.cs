/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF ViewModel class for Orders
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Northwind.Model;
using Northwind.Helper;

namespace Northwind.ViewModels
{
    public class OrdersSearchViewModel : ViewModelBase
	{
		#region Private Members
		private OrdersData _OrdersData;
		private string _filterExpression;
		private OrdersListViewModel _parentViewModel;
		#endregion

		#region Page Properties
		/// <summary>
		/// for validation if number
		/// </summary>
		public OrdersData OrdersData
		{
			get
			{
				return _OrdersData;
			}
			set
			{
				_OrdersData = value;
				OnPropertyChanged("OrdersData");
			}
		}
		public OrdersListViewModel ParentViewModel
		{
			get { return _parentViewModel; }
			set
			{
				_parentViewModel = value;
				OnPropertyChanged("ParentViewModel");
			}
		}
		public string FilterExpression
		{
			get { return _filterExpression; }
			set
			{
				_filterExpression = value;
				_parentViewModel.FilterExpression = value;
				OnPropertyChanged("FilterExpression");
			}
		}
		// Lookup Lists
		public List<EmployeesData> EmployeesList { get; set; }
		private int _selectedEmployeeIDIndex;
		public int SelectedEmployeeIDIndex
		{
			get { return _selectedEmployeeIDIndex; }
			set
			{
				_selectedEmployeeIDIndex = (value < 0 ? 0 : value);
				if (OrdersData != null && EmployeesList != null && EmployeesList.Any())
				{
					OrdersData.EmployeeID = EmployeesList[_selectedEmployeeIDIndex].EmployeeID;
				}
				OnPropertyChanged("OrdersData");
				OnPropertyChanged("SelectedEmployeeIDIndex");
			}
		}
		public List<CustomersData> CustomersList { get; set; }
		private int _selectedCustomerIDIndex;
		public int SelectedCustomerIDIndex
		{
			get { return _selectedCustomerIDIndex; }
			set
			{
				_selectedCustomerIDIndex = (value < 0 ? 0 : value);
				if (OrdersData != null && CustomersList != null && CustomersList.Any())
				{
					OrdersData.CustomerID = CustomersList[_selectedCustomerIDIndex].CustomerID;
				}
				OnPropertyChanged("OrdersData");
				OnPropertyChanged("SelectedCustomerIDIndex");
			}
		}

        #endregion

        #region Commands Definition
        public ICommand SearchCommand { get; set; }
        public ICommand ClearSearchCommand { get; set; }
 		#endregion

		#region Page View Model
		public OrdersSearchViewModel()
        {
            try
            {
				this.OrdersData = new OrdersData();
                this.EmployeesList = Employees.GetList("");
				this.EmployeesList.Insert(0, new EmployeesData() { EmployeeID = 0, LastName = "SELECT" });
                this.CustomersList = Customers.GetList("");
				this.CustomersList.Insert(0, new CustomersData() { CustomerID = "", CompanyName = "SELECT" });

                this.SearchCommand = new RelayCommand((p) =>
                {
					if (!string.IsNullOrEmpty(this.Error))
					{
						return;
					}

					this.FilterExpression = string.Empty;
                    System.Text.StringBuilder sbFilterExpression = new System.Text.StringBuilder();
					

					if (OrdersData.OrderID != 0)
						sbFilterExpression.AppendFormat("OrderID = {0} AND ", OrdersData.OrderID);
		
					if (OrdersData.CustomerID != string.Empty)
						sbFilterExpression.AppendFormat("CustomerID like '%{0}%' AND ", OrdersData.CustomerID);
		
					if (OrdersData.EmployeeID != 0)
						sbFilterExpression.AppendFormat("EmployeeID = {0} AND ", OrdersData.EmployeeID);
		
					if (OrdersData.OrderDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("OrderDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(OrdersData.OrderDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(OrdersData.OrderDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (OrdersData.RequiredDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("RequiredDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(OrdersData.RequiredDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(OrdersData.RequiredDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (OrdersData.ShippedDate != DateTime.MinValue)
						sbFilterExpression.AppendFormat("ShippedDate BETWEEN '{0}' AND '{1}' AND ", Convert.ToDateTime(OrdersData.ShippedDate).ToString("yyyy-MM-dd"), Convert.ToDateTime(OrdersData.ShippedDate).AddDays(1).ToString("yyyy-MM-dd"));
		
					if (OrdersData.ShipVia != 0)
						sbFilterExpression.AppendFormat("ShipVia = {0} AND ", OrdersData.ShipVia);
		
					if (OrdersData.Freight != 0)
						sbFilterExpression.AppendFormat("Freight = {0} AND ", OrdersData.Freight);
		
					if (OrdersData.ShipName != string.Empty)
						sbFilterExpression.AppendFormat("ShipName like '%{0}%' AND ", OrdersData.ShipName);
		
					if (OrdersData.ShipAddress != string.Empty)
						sbFilterExpression.AppendFormat("ShipAddress like '%{0}%' AND ", OrdersData.ShipAddress);
		
					if (OrdersData.ShipCity != string.Empty)
						sbFilterExpression.AppendFormat("ShipCity like '%{0}%' AND ", OrdersData.ShipCity);
		
					if (OrdersData.ShipRegion != string.Empty)
						sbFilterExpression.AppendFormat("ShipRegion like '%{0}%' AND ", OrdersData.ShipRegion);
		
					if (OrdersData.ShipPostalCode != string.Empty)
						sbFilterExpression.AppendFormat("ShipPostalCode like '%{0}%' AND ", OrdersData.ShipPostalCode);
		
					if (OrdersData.ShipCountry != string.Empty)
						sbFilterExpression.AppendFormat("ShipCountry like '%{0}%' AND ", OrdersData.ShipCountry);
		
					if (sbFilterExpression.Length > 0)
                    {
	                    sbFilterExpression.Remove(sbFilterExpression.Length - 4, 4);
	                    this.FilterExpression = sbFilterExpression.ToString();
					}
				}, p => this.CanSearch);

                this.ClearSearchCommand = new RelayCommand((p) =>
                {
					OrdersData = null;
					OrdersData = new OrdersData();
					this.FilterExpression = string.Empty;
                });
            }
            catch (Exception ex)
            {
                MessageService.ShowMessage(ex.Message);
            }
        }
		#endregion

		bool CanSearch
		{
			get
			{
				return OrdersData.IsValid;
			}
		}
    }
}
