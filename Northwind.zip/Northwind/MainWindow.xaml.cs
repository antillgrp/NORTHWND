using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Northwind.ViewModels;

namespace Northwind
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{

            string _data_Directory = AppDomain.CurrentDomain.BaseDirectory;
            _data_Directory = System.IO.Directory.GetParent(_data_Directory).Parent.Parent.FullName;
            /*DEBUG*/
            //System.Windows.MessageBox.Show("DB DIRECTORY:" + _data_Directory);
            /*END DEBUG*/

            AppDomain.CurrentDomain.SetData("DataDirectory", _data_Directory);
            
            InitializeComponent();
			this.DataContext = new MainWindowViewModel();
		}
	}
}
