/* ------------------------------------------------------------
 * Created By	: [GENERATOR_TOOL_NAME]
 * Created Date	: [CREATED_DATE]
 * Purpose		: WPF XAML View Codebehind for AppSettingsSearch
 * ------------------------------------------------------------
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Northwind.Views
{
    /// <summary>
    /// AppSettingsSearch.xaml
    /// </summary>
    public partial class AppSettingsSearch : UserControl
    {
		public AppSettingsSearch()
        {
            InitializeComponent();
        }
    }
}
