using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Globalization;

namespace Northwind.Model
{
	public class RequiredFieldValidator : ValidationRule
	{
		private string _errorMessage;
		public string ErrorMessage
		{
			get { return _errorMessage; }
			set { _errorMessage = value; }
		}

		public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
		{
			if (value == null || string.IsNullOrEmpty(value.ToString()))
				return new ValidationResult(false, _errorMessage);
			else
				return new ValidationResult(true, null);

		}
	}

	public class IntValidationRule : ValidationRule
	{
		public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
		{
			int i;
			if (int.TryParse(value.ToString(), out i))
				return new ValidationResult(true, null);

			return new ValidationResult(false, "Please enter a valid integer value.");
		}
	}

	public class RegExValidator : ValidationRule
	{
		private string _regex;
		private string _errorMessage;
		public RegExValidator()
		{
		}

		public string RegularExpression
		{
			get { return _regex; }
			set { _regex = value; }
		}
		public string ErrorMessage
		{
			get { return _errorMessage; }
			set { _errorMessage = value; }
		}
		public override ValidationResult Validate(object value, CultureInfo cultureInfo)
		{
			System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex(_regex);
			bool isValid = reg.IsMatch(value.ToString());
			if (isValid)
				return new ValidationResult(true, null);
			else
				return new ValidationResult(false, _errorMessage);
		}
	}

	public class NumericRangeValidator : ValidationRule
	{
		private int _min;
		private int _max;
		private string _errorMessage;
		public NumericRangeValidator()
		{
		}

		public int Min
		{
			get { return _min; }
			set { _min = value; }
		}

		public int Max
		{
			get { return _max; }
			set { _max = value; }
		}

		public string ErrorMessage
		{
			get { return _errorMessage; }
			set { _errorMessage = value; }
		}

		public override ValidationResult Validate(object value, CultureInfo cultureInfo)
		{
			int _value = int.Parse(value.ToString());

			//if (!int.TryParse(value.ToString(), out _value))
			//    return new ValidationResult(false, "Please enter a valid integer value.");
			//else 
			if ((_value < Min) || (_value > Max))
			{
				return new ValidationResult(false,
				  "Please enter value between: " + Min + " and " + Max + ".");
			}
			else
			{
				return new ValidationResult(true, null);
			}
		}
	}

	public class DropdownValidator : ValidationRule
	{
		private string _defaultValue;
		private string _errorMessage;
		public DropdownValidator()
		{
		}

		public string DefaultValue
		{
			get { return _defaultValue; }
			set { _defaultValue = value; }
		}
		public string ErrorMessage
		{
			get { return _errorMessage; }
			set { _errorMessage = value; }
		}
		public override ValidationResult Validate(object value, CultureInfo cultureInfo)
		{
			if (value == null || value.ToString().Equals("0") || string.IsNullOrEmpty(value.ToString()))
				return new ValidationResult(false, _errorMessage);
			else
				return new ValidationResult(true, null);
		}
	}

}