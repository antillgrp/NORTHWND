using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Northwind.Helper
{
    public class MessageService
    {
        public static Action<string> ShowMessage;

        public static Func<string, MessageBoxResult> ShowMessageWithConfirm;
    }
}
