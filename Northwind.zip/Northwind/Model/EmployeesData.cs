/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for Employees
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class EmployeesData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public EmployeesData() { }
		
		public EmployeesData(int employeeid,string lastname,string firstname,string title,string titleofcourtesy,DateTime birthdate,DateTime hiredate,string address,string city,string region,string postalcode,string country,string homephone,string extension,byte[] photo,string notes,int reportsto,string photopath)
		{
				this.EmployeeID = employeeid;
			this.LastName = lastname;
			this.FirstName = firstname;
			this.Title = title;
			this.TitleOfCourtesy = titleofcourtesy;
			this.BirthDate = birthdate;
			this.HireDate = hiredate;
			this.Address = address;
			this.City = city;
			this.Region = region;
			this.PostalCode = postalcode;
			this.Country = country;
			this.HomePhone = homephone;
			this.Extension = extension;
			this.Photo = photo;
			this.Notes = notes;
			this.ReportsTo = reportsto;
			this.PhotoPath = photopath;

		}

		public EmployeesData(IDataReader objReader)
		{
			m_EmployeeID = (int) (DBNull.Value.Equals(objReader["EmployeeID"]) ? 0 : objReader["EmployeeID"]);
			m_LastName = (string) (DBNull.Value.Equals(objReader["LastName"]) ? string.Empty : objReader["LastName"]);
			m_FirstName = (string) (DBNull.Value.Equals(objReader["FirstName"]) ? string.Empty : objReader["FirstName"]);
			m_Title = (string) (DBNull.Value.Equals(objReader["Title"]) ? string.Empty : objReader["Title"]);
			m_TitleOfCourtesy = (string) (DBNull.Value.Equals(objReader["TitleOfCourtesy"]) ? string.Empty : objReader["TitleOfCourtesy"]);
			m_BirthDate = (DateTime) (DBNull.Value.Equals(objReader["BirthDate"]) ? DateTime.MinValue : objReader["BirthDate"]);
			m_HireDate = (DateTime) (DBNull.Value.Equals(objReader["HireDate"]) ? DateTime.MinValue : objReader["HireDate"]);
			m_Address = (string) (DBNull.Value.Equals(objReader["Address"]) ? string.Empty : objReader["Address"]);
			m_City = (string) (DBNull.Value.Equals(objReader["City"]) ? string.Empty : objReader["City"]);
			m_Region = (string) (DBNull.Value.Equals(objReader["Region"]) ? string.Empty : objReader["Region"]);
			m_PostalCode = (string) (DBNull.Value.Equals(objReader["PostalCode"]) ? string.Empty : objReader["PostalCode"]);
			m_Country = (string) (DBNull.Value.Equals(objReader["Country"]) ? string.Empty : objReader["Country"]);
			m_HomePhone = (string) (DBNull.Value.Equals(objReader["HomePhone"]) ? string.Empty : objReader["HomePhone"]);
			m_Extension = (string) (DBNull.Value.Equals(objReader["Extension"]) ? string.Empty : objReader["Extension"]);
			m_Photo = (byte[]) (DBNull.Value.Equals(objReader["Photo"]) ? string.Empty : objReader["Photo"]);
			m_Notes = (string) (DBNull.Value.Equals(objReader["Notes"]) ? string.Empty : objReader["Notes"]);
			m_ReportsTo = (int) (DBNull.Value.Equals(objReader["ReportsTo"]) ? 0 : objReader["ReportsTo"]);
			m_PhotoPath = (string) (DBNull.Value.Equals(objReader["PhotoPath"]) ? string.Empty : objReader["PhotoPath"]);
		}
		#endregion

		#region Properties
		
			private int m_EmployeeID = 0;
			public int EmployeeID
			{
				get { return m_EmployeeID;}
				set
				{
					m_EmployeeID = value;
					RaisePropertyChanged("EmployeeID");
				}
			}
		
			private string m_LastName = string.Empty;
			public string LastName
			{
				get { return m_LastName;}
				set
				{
					m_LastName = value;
					RaisePropertyChanged("LastName");
				}
			}
		
			private string m_FirstName = string.Empty;
			public string FirstName
			{
				get { return m_FirstName;}
				set
				{
					m_FirstName = value;
					RaisePropertyChanged("FirstName");
				}
			}
		
			private string m_Title = string.Empty;
			public string Title
			{
				get { return m_Title;}
				set
				{
					m_Title = value;
					RaisePropertyChanged("Title");
				}
			}
		
			private string m_TitleOfCourtesy = string.Empty;
			public string TitleOfCourtesy
			{
				get { return m_TitleOfCourtesy;}
				set
				{
					m_TitleOfCourtesy = value;
					RaisePropertyChanged("TitleOfCourtesy");
				}
			}
		
			private DateTime m_BirthDate = DateTime.MinValue;
			public DateTime BirthDate
			{
				get { return m_BirthDate;}
				set
				{
					m_BirthDate = value;
					RaisePropertyChanged("BirthDate");
				}
			}
		
			private DateTime m_HireDate = DateTime.MinValue;
			public DateTime HireDate
			{
				get { return m_HireDate;}
				set
				{
					m_HireDate = value;
					RaisePropertyChanged("HireDate");
				}
			}
		
			private string m_Address = string.Empty;
			public string Address
			{
				get { return m_Address;}
				set
				{
					m_Address = value;
					RaisePropertyChanged("Address");
				}
			}
		
			private string m_City = string.Empty;
			public string City
			{
				get { return m_City;}
				set
				{
					m_City = value;
					RaisePropertyChanged("City");
				}
			}
		
			private string m_Region = string.Empty;
			public string Region
			{
				get { return m_Region;}
				set
				{
					m_Region = value;
					RaisePropertyChanged("Region");
				}
			}
		
			private string m_PostalCode = string.Empty;
			public string PostalCode
			{
				get { return m_PostalCode;}
				set
				{
					m_PostalCode = value;
					RaisePropertyChanged("PostalCode");
				}
			}
		
			private string m_Country = string.Empty;
			public string Country
			{
				get { return m_Country;}
				set
				{
					m_Country = value;
					RaisePropertyChanged("Country");
				}
			}
		
			private string m_HomePhone = string.Empty;
			public string HomePhone
			{
				get { return m_HomePhone;}
				set
				{
					m_HomePhone = value;
					RaisePropertyChanged("HomePhone");
				}
			}
		
			private string m_Extension = string.Empty;
			public string Extension
			{
				get { return m_Extension;}
				set
				{
					m_Extension = value;
					RaisePropertyChanged("Extension");
				}
			}
		
			private byte[] m_Photo = new byte[] {};
			public byte[] Photo
			{
				get { return m_Photo;}
				set
				{
					m_Photo = value;
					RaisePropertyChanged("Photo");
				}
			}
		
			private string m_Notes = string.Empty;
			public string Notes
			{
				get { return m_Notes;}
				set
				{
					m_Notes = value;
					RaisePropertyChanged("Notes");
				}
			}
		
			private int m_ReportsTo = 0;
			public int ReportsTo
			{
				get { return m_ReportsTo;}
				set
				{
					m_ReportsTo = value;
					RaisePropertyChanged("ReportsTo");
				}
			}
		
			private string m_PhotoPath = string.Empty;
			public string PhotoPath
			{
				get { return m_PhotoPath;}
				set
				{
					m_PhotoPath = value;
					RaisePropertyChanged("PhotoPath");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}