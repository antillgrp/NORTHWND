/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: This is class contains methods to perform Data Access Layer operations 
 * ------------------------------------------------------------
*/

#region Using Statements	
using System;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
#endregion

namespace Northwind.Model
{
	/// <summary>
	/// Summary description for AppSettings.
	/// </summary>
    public class AppSettings
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["defaultDatabase"].ConnectionString;
		
		#region Constants
		private const string SP_GET_ALL = "SELECT  OptionID, KeyName, KeyValue, Comments, CreatedDate, UpdatedDate FROM AppSettings WITH (NOLOCK)";
		private const string SP_GET_FILTER = "SELECT  OptionID, KeyName, KeyValue, Comments, CreatedDate, UpdatedDate FROM AppSettings WITH (NOLOCK) {0}";
		private const string SP_GET_BYPAGE = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY {0}) AS rownumber, * FROM AppSettings {1}) AS tblOutput WHERE rownumber BETWEEN {2} AND {3} SELECT COUNT(*) FROM AppSettings WITH (NOLOCK) {4}";
		private const string SP_GET_BYID = "SELECT  OptionID, KeyName, KeyValue, Comments, CreatedDate, UpdatedDate FROM AppSettings WITH (NOLOCK) WHERE OptionID = @ref_id";
		private const string SP_ADD = "INSERT INTO AppSettings ( KeyName, KeyValue, Comments, CreatedDate, UpdatedDate) VALUES ( @KeyName, @KeyValue, @Comments, @CreatedDate, @UpdatedDate)  SELECT SCOPE_IDENTITY() ";
		private const string SP_ADD1 = "INSERT INTO AppSettings ( KeyName, KeyValue, Comments, CreatedDate, UpdatedDate) VALUES ( @KeyName, @KeyValue, @Comments, @CreatedDate, @UpdatedDate) SELECT @OptionID = @@IDENTITY";
		private const string SP_UPDATE = "UPDATE AppSettings SET KeyName = @KeyName, KeyValue = @KeyValue, Comments = @Comments, CreatedDate = @CreatedDate, UpdatedDate = @UpdatedDate WHERE OptionID = @OptionID";
		private const string SP_DELETE = "DELETE FROM AppSettings WHERE OptionID=@ref_id";
		private const string SP_DELETE_FILTER = "DELETE FROM AppSettings {0}";
		private const string SP_GET_LOOKUP = "SELECT OptionID, KeyName FROM AppSettings WITH (NOLOCK)";
		#endregion
		
		#region AppSettings - Constructor
		private AppSettings()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#endregion
        
		#region AppSettings - List AppSettings
		/// <summary>
		/// The purpose of this method is to get all AppSettings data.
		/// </summary>
		/// <returns>DataSet object</returns>
		public static DataSet GetData()
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();

                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region AppSettings - List AppSettings by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all AppSettings data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>DataSet object</returns>
		public static DataSet GetData(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region AppSettings - List AppSettings by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all AppSettings data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>DataSet object</returns>
        public static DataSet GetData(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					int lbound = ((pageIndex - 1) * pageSize) +1;
					int ubound = lbound + pageSize - 1;
					string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        rowsCount = Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString());
                        return ds;
                    }
                }
            }
        }
		#endregion
        
        #region AppSettings - Get Details for an AppSettings record
        /// <summary>
		/// The purpose of this method is to get the data based on specified primary key value
		/// </summary>
		/// <param name="sRefID">Primary key value</param>
		/// <returns></returns>
		public static DataSet GetDetails(string sRefID)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					string strSQL = string.Format(SP_GET_BYID, sRefID);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@ref_id", sRefID);
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        //[GET_VALUEBYID_METHOD]
        
        #region AppSettings - Get Lookup Data
        /// <summary>
        /// The purpose of this method is to get the lookup data
        /// </summary>
        /// <returns>returns Lookup Data as DataSet</returns>
        public static DataSet GetLookup()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				using (SqlDataAdapter da = new SqlDataAdapter())
				{
					using (SqlCommand cmd = new SqlCommand(SP_GET_LOOKUP, cn))
					{
						cmd.CommandType = CommandType.Text;
						DataSet ds = new DataSet();

						da.SelectCommand = cmd;
						da.Fill(ds);
						return ds;
					}
				}
            }
        }
        #endregion
		
        
		#region AppSettings - Add Record
        /// <summary>
        /// Creates a new AppSettings row.
        /// </summary>
        public static long Add( long OptionID, string KeyName, string KeyValue, string Comments, DateTime CreatedDate, DateTime UpdatedDate)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_ADD, cn))
                {
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@KeyName", KeyName);
					cmd.Parameters.AddWithValue("@KeyValue", KeyValue);
					cmd.Parameters.AddWithValue("@Comments", Comments);
					cmd.Parameters.AddWithValue("@CreatedDate", CreatedDate);
					cmd.Parameters.AddWithValue("@UpdatedDate", UpdatedDate);
					cn.Open();
					object id = cmd.ExecuteScalar();
					return long.Parse(id.ToString());
                }
            }
        }
        #endregion
        
		#region AppSettings - Update Record
        /// <summary>
        /// Updates a AppSettings
        /// </summary>
        public static bool Update( long OptionID, string KeyName, string KeyValue, string Comments, DateTime CreatedDate, DateTime UpdatedDate)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_UPDATE, cn))
                {
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@OptionID", OptionID);
					cmd.Parameters.AddWithValue("@KeyName", KeyName);
					cmd.Parameters.AddWithValue("@KeyValue", KeyValue);
					cmd.Parameters.AddWithValue("@Comments", Comments);
					cmd.Parameters.AddWithValue("@CreatedDate", CreatedDate);
					cmd.Parameters.AddWithValue("@UpdatedDate", UpdatedDate);
					cn.Open();
					int rowsAffected = cmd.ExecuteNonQuery();
					return (rowsAffected == 1);
                }
            }
        }
        #endregion
        
        #region AppSettings - Delete Record
        /// <summary>
        /// The purpose of this method is to delete the record based on specified primary key value
        /// </summary>
        /// <param name="sRefID">Primary key value</param>
        /// <returns></returns>
        public static bool Delete(string sRefID)
        {
            bool bDeleted = false;
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_DELETE, cn))
                {
                    cmd.CommandType = CommandType.Text;
	                //cmd.Parameters.Add("@OptionID", SqlDbType.long).Value = sRefID;
                    cmd.Parameters.AddWithValue("@ref_id", sRefID);
                    cn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    bDeleted = (rowsAffected == 1);
                }
            }
            return bDeleted;
        }
        #endregion
        
        #region AppSettings - Delete Records
        /// <summary>
        /// The purpose of this method is to delete all AppSettings data based on the Filter Expression criteria.
        /// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
        /// <returns>Returns the number of rows deleted</returns>
        public static int DeleteFilter(string filterExpression)
        {
            int rowsAffected = 0;
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
				string strSQL = string.Format(SP_DELETE_FILTER, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                }
            }
            return rowsAffected;
        }
        #endregion
        
        #region AppSettings - Get List of AppSettingsData objects
        /// <summary>
        /// Returns a collection with all the AppSettingsData
        /// </summary>
		/// <returns>List<AppSettingsData> object</returns>
        public static List<AppSettingsData> GetList()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<AppSettingsData> objList = new List<AppSettingsData>();
					while (reader.Read())
					{
						//objList.Add(new AppSettingsData(
						//	 (long) reader["OptionID"], (string) reader["KeyName"], (string) reader["KeyValue"], (string) reader["Comments"], (DateTime) reader["CreatedDate"], (DateTime) reader["UpdatedDate"]));
						objList.Add(new AppSettingsData(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
        }
        #endregion
        
		
		#region AppSettings - List AppSettings by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all AppSettings data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>List<DataClass> object</returns>
		public static List<AppSettingsData> GetList(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
				string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cmd.Parameters.AddWithValue("@where_clause", filterExpression);
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<AppSettingsData> objList = new List<AppSettingsData>();
					while (reader.Read())
					{
						//objList.Add(new AppSettingsData(
						//	 (long) reader["OptionID"], (string) reader["KeyName"], (string) reader["KeyValue"], (string) reader["Comments"], (DateTime) reader["CreatedDate"], (DateTime) reader["UpdatedDate"]));
						objList.Add(new AppSettingsData(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
		}
		#endregion
		
        #region AppSettings - List AppSettings by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all AppSettings data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>List<AppSettingsData> object</returns>
        public static List<AppSettingsData> GetList(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
                int lbound = ((pageIndex - 1) * pageSize) + 1;
                int ubound = lbound + pageSize - 1;
                string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

                    List<AppSettingsData> objList = new List<AppSettingsData>();
                    while (reader.Read())
                    {
                        //objList.Add(new AppSettingsData(
                        //         (long) reader["OptionID"], (string) reader["KeyName"], (string) reader["KeyValue"], (string) reader["Comments"], (DateTime) reader["CreatedDate"], (DateTime) reader["UpdatedDate"]));
						objList.Add(new AppSettingsData(reader)); // Use this to avoid null issues
                    }
                    reader.NextResult();
                    reader.Read();
                    rowsCount = Convert.ToInt32(reader[0]);
                    reader.Close();

                    return objList;
                }
            }
        }
        #endregion
        
        
		#region AppSettings - Get Details by ID
        /// <summary>
        /// Returns an existing AppSettingsData object with the specified ID 
        /// </summary>
        public static AppSettingsData GetDetailsByID(long sRefID)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(SP_GET_BYID, cn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ref_id", sRefID);
                cn.Open();
                
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    // return new AppSettingsData(
					//	 (long) reader["OptionID"], (string) reader["KeyName"], (string) reader["KeyValue"], (string) reader["Comments"], (DateTime) reader["CreatedDate"], (DateTime) reader["UpdatedDate"]);
					return new AppSettingsData(reader); // Use this to avoid null issues
                }
                else
                    return null;
            }
        }
		#endregion
        
		#region AppSettings - Add Record
        /// <summary>
        /// Creates a new AppSettings
        /// </summary>
        public static long Add(AppSettingsData objAppSettings)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_ADD, cn))
                {
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@KeyName", objAppSettings.KeyName);
					cmd.Parameters.AddWithValue("@KeyValue", objAppSettings.KeyValue);
					cmd.Parameters.AddWithValue("@Comments", objAppSettings.Comments);
					cmd.Parameters.AddWithValue("@CreatedDate", objAppSettings.CreatedDate);
					cmd.Parameters.AddWithValue("@UpdatedDate", objAppSettings.UpdatedDate);
					cn.Open();
					object id = cmd.ExecuteScalar();
					return long.Parse(id.ToString());
                }
            }
        }
        #endregion
        
		#region AppSettings - Update Record
		/// <summary>
		/// Updates a AppSettings
		/// </summary>
		public static bool Update(AppSettingsData objAppSettings)
		{
			using (SqlConnection cn = new SqlConnection(connectionString))
			{
				using (SqlCommand cmd = new SqlCommand(SP_UPDATE, cn))
				{
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@OptionID", objAppSettings.OptionID);
					cmd.Parameters.AddWithValue("@KeyName", objAppSettings.KeyName);
					cmd.Parameters.AddWithValue("@KeyValue", objAppSettings.KeyValue);
					cmd.Parameters.AddWithValue("@Comments", objAppSettings.Comments);
					cmd.Parameters.AddWithValue("@CreatedDate", objAppSettings.CreatedDate);
					cmd.Parameters.AddWithValue("@UpdatedDate", objAppSettings.UpdatedDate);
					cn.Open();
					int rowsAffected = cmd.ExecuteNonQuery();
					return (rowsAffected == 1);
				}
			}
		}
		#endregion
    }
}
  