/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for Suppliers
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class SuppliersData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public SuppliersData() { }
		
		public SuppliersData(int supplierid,string companyname,string contactname,string contacttitle,string address,string city,string region,string postalcode,string country,string phone,string fax,string homepage)
		{
				this.SupplierID = supplierid;
			this.CompanyName = companyname;
			this.ContactName = contactname;
			this.ContactTitle = contacttitle;
			this.Address = address;
			this.City = city;
			this.Region = region;
			this.PostalCode = postalcode;
			this.Country = country;
			this.Phone = phone;
			this.Fax = fax;
			this.HomePage = homepage;

		}

		public SuppliersData(IDataReader objReader)
		{
			m_SupplierID = (int) (DBNull.Value.Equals(objReader["SupplierID"]) ? 0 : objReader["SupplierID"]);
			m_CompanyName = (string) (DBNull.Value.Equals(objReader["CompanyName"]) ? string.Empty : objReader["CompanyName"]);
			m_ContactName = (string) (DBNull.Value.Equals(objReader["ContactName"]) ? string.Empty : objReader["ContactName"]);
			m_ContactTitle = (string) (DBNull.Value.Equals(objReader["ContactTitle"]) ? string.Empty : objReader["ContactTitle"]);
			m_Address = (string) (DBNull.Value.Equals(objReader["Address"]) ? string.Empty : objReader["Address"]);
			m_City = (string) (DBNull.Value.Equals(objReader["City"]) ? string.Empty : objReader["City"]);
			m_Region = (string) (DBNull.Value.Equals(objReader["Region"]) ? string.Empty : objReader["Region"]);
			m_PostalCode = (string) (DBNull.Value.Equals(objReader["PostalCode"]) ? string.Empty : objReader["PostalCode"]);
			m_Country = (string) (DBNull.Value.Equals(objReader["Country"]) ? string.Empty : objReader["Country"]);
			m_Phone = (string) (DBNull.Value.Equals(objReader["Phone"]) ? string.Empty : objReader["Phone"]);
			m_Fax = (string) (DBNull.Value.Equals(objReader["Fax"]) ? string.Empty : objReader["Fax"]);
			m_HomePage = (string) (DBNull.Value.Equals(objReader["HomePage"]) ? string.Empty : objReader["HomePage"]);
		}
		#endregion

		#region Properties
		
			private int m_SupplierID = 0;
			public int SupplierID
			{
				get { return m_SupplierID;}
				set
				{
					m_SupplierID = value;
					RaisePropertyChanged("SupplierID");
				}
			}
		
			private string m_CompanyName = string.Empty;
			public string CompanyName
			{
				get { return m_CompanyName;}
				set
				{
					m_CompanyName = value;
					RaisePropertyChanged("CompanyName");
				}
			}
		
			private string m_ContactName = string.Empty;
			public string ContactName
			{
				get { return m_ContactName;}
				set
				{
					m_ContactName = value;
					RaisePropertyChanged("ContactName");
				}
			}
		
			private string m_ContactTitle = string.Empty;
			public string ContactTitle
			{
				get { return m_ContactTitle;}
				set
				{
					m_ContactTitle = value;
					RaisePropertyChanged("ContactTitle");
				}
			}
		
			private string m_Address = string.Empty;
			public string Address
			{
				get { return m_Address;}
				set
				{
					m_Address = value;
					RaisePropertyChanged("Address");
				}
			}
		
			private string m_City = string.Empty;
			public string City
			{
				get { return m_City;}
				set
				{
					m_City = value;
					RaisePropertyChanged("City");
				}
			}
		
			private string m_Region = string.Empty;
			public string Region
			{
				get { return m_Region;}
				set
				{
					m_Region = value;
					RaisePropertyChanged("Region");
				}
			}
		
			private string m_PostalCode = string.Empty;
			public string PostalCode
			{
				get { return m_PostalCode;}
				set
				{
					m_PostalCode = value;
					RaisePropertyChanged("PostalCode");
				}
			}
		
			private string m_Country = string.Empty;
			public string Country
			{
				get { return m_Country;}
				set
				{
					m_Country = value;
					RaisePropertyChanged("Country");
				}
			}
		
			private string m_Phone = string.Empty;
			public string Phone
			{
				get { return m_Phone;}
				set
				{
					m_Phone = value;
					RaisePropertyChanged("Phone");
				}
			}
		
			private string m_Fax = string.Empty;
			public string Fax
			{
				get { return m_Fax;}
				set
				{
					m_Fax = value;
					RaisePropertyChanged("Fax");
				}
			}
		
			private string m_HomePage = string.Empty;
			public string HomePage
			{
				get { return m_HomePage;}
				set
				{
					m_HomePage = value;
					RaisePropertyChanged("HomePage");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}