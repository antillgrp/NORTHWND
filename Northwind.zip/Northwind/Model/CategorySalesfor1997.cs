/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: This is class contains methods to perform Data Access Layer operations 
 * ------------------------------------------------------------
*/

#region Using Statements	
using System;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
#endregion

namespace Northwind.Model
{
	/// <summary>
	/// Summary description for CategorySalesfor1997.
	/// </summary>
    public class CategorySalesfor1997
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["defaultDatabase"].ConnectionString;
		
		#region Constants
		private const string SP_GET_ALL = "SELECT  CategoryName, CategorySales FROM [Category Sales for 1997] WITH (NOLOCK)";
		private const string SP_GET_FILTER = "SELECT  CategoryName, CategorySales FROM [Category Sales for 1997] WITH (NOLOCK) {0}";
		private const string SP_GET_BYPAGE = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY {0}) AS rownumber, * FROM [Category Sales for 1997] {1}) AS tblOutput WHERE rownumber BETWEEN {2} AND {3} SELECT COUNT(*) FROM [Category Sales for 1997] WITH (NOLOCK) {4}";
		private const string SP_GET_BYID = "SELECT  CategoryName, CategorySales FROM [Category Sales for 1997] WITH (NOLOCK) WHERE CategoryName = @ref_id";
		private const string SP_ADD = "INSERT INTO [Category Sales for 1997] ([INSERT_COLUMNS]) VALUES ([INSERT_COLUMN_VALUES]) ";
		private const string SP_ADD1 = "INSERT INTO [Category Sales for 1997] ([INSERT_COLUMNS]) VALUES ([INSERT_COLUMN_VALUES]) SELECT @CategoryName = @@IDENTITY";
		private const string SP_UPDATE = "UPDATE [Category Sales for 1997] SET [TABLE_COLUMNS_UPDATE] WHERE CategoryName = @CategoryName";
		private const string SP_DELETE = "DELETE FROM [Category Sales for 1997] WHERE CategoryName=@ref_id";
		private const string SP_DELETE_FILTER = "DELETE FROM [Category Sales for 1997] {0}";
		private const string SP_GET_LOOKUP = "SELECT CategoryName, CategoryName FROM [Category Sales for 1997] WITH (NOLOCK)";
		#endregion
		
		#region CategorySalesfor1997 - Constructor
		private CategorySalesfor1997()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#endregion
        
		#region CategorySalesfor1997 - List CategorySalesfor1997
		/// <summary>
		/// The purpose of this method is to get all CategorySalesfor1997 data.
		/// </summary>
		/// <returns>DataSet object</returns>
		public static DataSet GetData()
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();

                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region CategorySalesfor1997 - List CategorySalesfor1997 by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all CategorySalesfor1997 data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>DataSet object</returns>
		public static DataSet GetData(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region CategorySalesfor1997 - List CategorySalesfor1997 by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all CategorySalesfor1997 data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>DataSet object</returns>
        public static DataSet GetData(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					int lbound = ((pageIndex - 1) * pageSize) +1;
					int ubound = lbound + pageSize - 1;
					string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        rowsCount = Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString());
                        return ds;
                    }
                }
            }
        }
		#endregion
        
        #region CategorySalesfor1997 - Get Details for an CategorySalesfor1997 record
        /// <summary>
		/// The purpose of this method is to get the data based on specified primary key value
		/// </summary>
		/// <param name="sRefID">Primary key value</param>
		/// <returns></returns>
		public static DataSet GetDetails(string sRefID)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					string strSQL = string.Format(SP_GET_BYID, sRefID);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@ref_id", sRefID);
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        //[GET_VALUEBYID_METHOD]
        
        #region [Category Sales for 1997] - Get Lookup Data
        /// <summary>
        /// The purpose of this method is to get the lookup data
        /// </summary>
        /// <returns>returns Lookup Data as DataSet</returns>
        public static DataSet GetLookup()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				using (SqlDataAdapter da = new SqlDataAdapter())
				{
					using (SqlCommand cmd = new SqlCommand(SP_GET_LOOKUP, cn))
					{
						cmd.CommandType = CommandType.Text;
						DataSet ds = new DataSet();

						da.SelectCommand = cmd;
						da.Fill(ds);
						return ds;
					}
				}
            }
        }
        #endregion
		
        
        
        
        
        
        #region [Category Sales for 1997] - Get List of CategorySalesfor1997Data objects
        /// <summary>
        /// Returns a collection with all the CategorySalesfor1997Data
        /// </summary>
		/// <returns>List<CategorySalesfor1997Data> object</returns>
        public static List<CategorySalesfor1997Data> GetList()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<CategorySalesfor1997Data> objList = new List<CategorySalesfor1997Data>();
					while (reader.Read())
					{
						//objList.Add(new CategorySalesfor1997Data(
						//	 (string) reader["CategoryName"], (decimal) reader["CategorySales"]));
						objList.Add(new CategorySalesfor1997Data(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
        }
        #endregion
        
		
		#region CategorySalesfor1997 - List CategorySalesfor1997 by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all CategorySalesfor1997 data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>List<DataClass> object</returns>
		public static List<CategorySalesfor1997Data> GetList(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
				string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cmd.Parameters.AddWithValue("@where_clause", filterExpression);
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<CategorySalesfor1997Data> objList = new List<CategorySalesfor1997Data>();
					while (reader.Read())
					{
						//objList.Add(new CategorySalesfor1997Data(
						//	 (string) reader["CategoryName"], (decimal) reader["CategorySales"]));
						objList.Add(new CategorySalesfor1997Data(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
		}
		#endregion
		
        #region [Category Sales for 1997] - List CategorySalesfor1997 by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all CategorySalesfor1997 data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>List<CategorySalesfor1997Data> object</returns>
        public static List<CategorySalesfor1997Data> GetList(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
                int lbound = ((pageIndex - 1) * pageSize) + 1;
                int ubound = lbound + pageSize - 1;
                string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

                    List<CategorySalesfor1997Data> objList = new List<CategorySalesfor1997Data>();
                    while (reader.Read())
                    {
                        //objList.Add(new CategorySalesfor1997Data(
                        //         (string) reader["CategoryName"], (decimal) reader["CategorySales"]));
						objList.Add(new CategorySalesfor1997Data(reader)); // Use this to avoid null issues
                    }
                    reader.NextResult();
                    reader.Read();
                    rowsCount = Convert.ToInt32(reader[0]);
                    reader.Close();

                    return objList;
                }
            }
        }
        #endregion
        
        
		#region CategorySalesfor1997 - Get Details by ID
        /// <summary>
        /// Returns an existing CategorySalesfor1997Data object with the specified ID 
        /// </summary>
        public static CategorySalesfor1997Data GetDetailsByID(string sRefID)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(SP_GET_BYID, cn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ref_id", sRefID);
                cn.Open();
                
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    // return new CategorySalesfor1997Data(
					//	 (string) reader["CategoryName"], (decimal) reader["CategorySales"]);
					return new CategorySalesfor1997Data(reader); // Use this to avoid null issues
                }
                else
                    return null;
            }
        }
		#endregion
        
        
    }
}
  