/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for Invoices
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class InvoicesData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public InvoicesData() { }
		
		public InvoicesData(string shipname,string shipaddress,string shipcity,string shipregion,string shippostalcode,string shipcountry,string customerid,string customername,string address,string city,string region,string postalcode,string country,string salesperson,int orderid,DateTime orderdate,DateTime requireddate,DateTime shippeddate,string shippername,int productid,string productname,decimal unitprice,short quantity,float discount,decimal extendedprice,decimal freight)
		{
				this.ShipName = shipname;
			this.ShipAddress = shipaddress;
			this.ShipCity = shipcity;
			this.ShipRegion = shipregion;
			this.ShipPostalCode = shippostalcode;
			this.ShipCountry = shipcountry;
			this.CustomerID = customerid;
			this.CustomerName = customername;
			this.Address = address;
			this.City = city;
			this.Region = region;
			this.PostalCode = postalcode;
			this.Country = country;
			this.Salesperson = salesperson;
			this.OrderID = orderid;
			this.OrderDate = orderdate;
			this.RequiredDate = requireddate;
			this.ShippedDate = shippeddate;
			this.ShipperName = shippername;
			this.ProductID = productid;
			this.ProductName = productname;
			this.UnitPrice = unitprice;
			this.Quantity = quantity;
			this.Discount = discount;
			this.ExtendedPrice = extendedprice;
			this.Freight = freight;

		}

		public InvoicesData(IDataReader objReader)
		{
			m_ShipName = (string) (DBNull.Value.Equals(objReader["ShipName"]) ? string.Empty : objReader["ShipName"]);
			m_ShipAddress = (string) (DBNull.Value.Equals(objReader["ShipAddress"]) ? string.Empty : objReader["ShipAddress"]);
			m_ShipCity = (string) (DBNull.Value.Equals(objReader["ShipCity"]) ? string.Empty : objReader["ShipCity"]);
			m_ShipRegion = (string) (DBNull.Value.Equals(objReader["ShipRegion"]) ? string.Empty : objReader["ShipRegion"]);
			m_ShipPostalCode = (string) (DBNull.Value.Equals(objReader["ShipPostalCode"]) ? string.Empty : objReader["ShipPostalCode"]);
			m_ShipCountry = (string) (DBNull.Value.Equals(objReader["ShipCountry"]) ? string.Empty : objReader["ShipCountry"]);
			m_CustomerID = (string) (DBNull.Value.Equals(objReader["CustomerID"]) ? string.Empty : objReader["CustomerID"]);
			m_CustomerName = (string) (DBNull.Value.Equals(objReader["CustomerName"]) ? string.Empty : objReader["CustomerName"]);
			m_Address = (string) (DBNull.Value.Equals(objReader["Address"]) ? string.Empty : objReader["Address"]);
			m_City = (string) (DBNull.Value.Equals(objReader["City"]) ? string.Empty : objReader["City"]);
			m_Region = (string) (DBNull.Value.Equals(objReader["Region"]) ? string.Empty : objReader["Region"]);
			m_PostalCode = (string) (DBNull.Value.Equals(objReader["PostalCode"]) ? string.Empty : objReader["PostalCode"]);
			m_Country = (string) (DBNull.Value.Equals(objReader["Country"]) ? string.Empty : objReader["Country"]);
			m_Salesperson = (string) (DBNull.Value.Equals(objReader["Salesperson"]) ? string.Empty : objReader["Salesperson"]);
			m_OrderID = (int) (DBNull.Value.Equals(objReader["OrderID"]) ? 0 : objReader["OrderID"]);
			m_OrderDate = (DateTime) (DBNull.Value.Equals(objReader["OrderDate"]) ? DateTime.MinValue : objReader["OrderDate"]);
			m_RequiredDate = (DateTime) (DBNull.Value.Equals(objReader["RequiredDate"]) ? DateTime.MinValue : objReader["RequiredDate"]);
			m_ShippedDate = (DateTime) (DBNull.Value.Equals(objReader["ShippedDate"]) ? DateTime.MinValue : objReader["ShippedDate"]);
			m_ShipperName = (string) (DBNull.Value.Equals(objReader["ShipperName"]) ? string.Empty : objReader["ShipperName"]);
			m_ProductID = (int) (DBNull.Value.Equals(objReader["ProductID"]) ? 0 : objReader["ProductID"]);
			m_ProductName = (string) (DBNull.Value.Equals(objReader["ProductName"]) ? string.Empty : objReader["ProductName"]);
			m_UnitPrice = (decimal) (DBNull.Value.Equals(objReader["UnitPrice"]) ? 0 : objReader["UnitPrice"]);
			m_Quantity = (short) (DBNull.Value.Equals(objReader["Quantity"]) ? 0 : objReader["Quantity"]);
			m_Discount = (float) (DBNull.Value.Equals(objReader["Discount"]) ? string.Empty : objReader["Discount"]);
			m_ExtendedPrice = (decimal) (DBNull.Value.Equals(objReader["ExtendedPrice"]) ? 0 : objReader["ExtendedPrice"]);
			m_Freight = (decimal) (DBNull.Value.Equals(objReader["Freight"]) ? 0 : objReader["Freight"]);
		}
		#endregion

		#region Properties
		
			private string m_ShipName = string.Empty;
			public string ShipName
			{
				get { return m_ShipName;}
				set
				{
					m_ShipName = value;
					RaisePropertyChanged("ShipName");
				}
			}
		
			private string m_ShipAddress = string.Empty;
			public string ShipAddress
			{
				get { return m_ShipAddress;}
				set
				{
					m_ShipAddress = value;
					RaisePropertyChanged("ShipAddress");
				}
			}
		
			private string m_ShipCity = string.Empty;
			public string ShipCity
			{
				get { return m_ShipCity;}
				set
				{
					m_ShipCity = value;
					RaisePropertyChanged("ShipCity");
				}
			}
		
			private string m_ShipRegion = string.Empty;
			public string ShipRegion
			{
				get { return m_ShipRegion;}
				set
				{
					m_ShipRegion = value;
					RaisePropertyChanged("ShipRegion");
				}
			}
		
			private string m_ShipPostalCode = string.Empty;
			public string ShipPostalCode
			{
				get { return m_ShipPostalCode;}
				set
				{
					m_ShipPostalCode = value;
					RaisePropertyChanged("ShipPostalCode");
				}
			}
		
			private string m_ShipCountry = string.Empty;
			public string ShipCountry
			{
				get { return m_ShipCountry;}
				set
				{
					m_ShipCountry = value;
					RaisePropertyChanged("ShipCountry");
				}
			}
		
			private string m_CustomerID = string.Empty;
			public string CustomerID
			{
				get { return m_CustomerID;}
				set
				{
					m_CustomerID = value;
					RaisePropertyChanged("CustomerID");
				}
			}
		
			private string m_CustomerName = string.Empty;
			public string CustomerName
			{
				get { return m_CustomerName;}
				set
				{
					m_CustomerName = value;
					RaisePropertyChanged("CustomerName");
				}
			}
		
			private string m_Address = string.Empty;
			public string Address
			{
				get { return m_Address;}
				set
				{
					m_Address = value;
					RaisePropertyChanged("Address");
				}
			}
		
			private string m_City = string.Empty;
			public string City
			{
				get { return m_City;}
				set
				{
					m_City = value;
					RaisePropertyChanged("City");
				}
			}
		
			private string m_Region = string.Empty;
			public string Region
			{
				get { return m_Region;}
				set
				{
					m_Region = value;
					RaisePropertyChanged("Region");
				}
			}
		
			private string m_PostalCode = string.Empty;
			public string PostalCode
			{
				get { return m_PostalCode;}
				set
				{
					m_PostalCode = value;
					RaisePropertyChanged("PostalCode");
				}
			}
		
			private string m_Country = string.Empty;
			public string Country
			{
				get { return m_Country;}
				set
				{
					m_Country = value;
					RaisePropertyChanged("Country");
				}
			}
		
			private string m_Salesperson = string.Empty;
			public string Salesperson
			{
				get { return m_Salesperson;}
				set
				{
					m_Salesperson = value;
					RaisePropertyChanged("Salesperson");
				}
			}
		
			private int m_OrderID = 0;
			public int OrderID
			{
				get { return m_OrderID;}
				set
				{
					m_OrderID = value;
					RaisePropertyChanged("OrderID");
				}
			}
		
			private DateTime m_OrderDate = DateTime.MinValue;
			public DateTime OrderDate
			{
				get { return m_OrderDate;}
				set
				{
					m_OrderDate = value;
					RaisePropertyChanged("OrderDate");
				}
			}
		
			private DateTime m_RequiredDate = DateTime.MinValue;
			public DateTime RequiredDate
			{
				get { return m_RequiredDate;}
				set
				{
					m_RequiredDate = value;
					RaisePropertyChanged("RequiredDate");
				}
			}
		
			private DateTime m_ShippedDate = DateTime.MinValue;
			public DateTime ShippedDate
			{
				get { return m_ShippedDate;}
				set
				{
					m_ShippedDate = value;
					RaisePropertyChanged("ShippedDate");
				}
			}
		
			private string m_ShipperName = string.Empty;
			public string ShipperName
			{
				get { return m_ShipperName;}
				set
				{
					m_ShipperName = value;
					RaisePropertyChanged("ShipperName");
				}
			}
		
			private int m_ProductID = 0;
			public int ProductID
			{
				get { return m_ProductID;}
				set
				{
					m_ProductID = value;
					RaisePropertyChanged("ProductID");
				}
			}
		
			private string m_ProductName = string.Empty;
			public string ProductName
			{
				get { return m_ProductName;}
				set
				{
					m_ProductName = value;
					RaisePropertyChanged("ProductName");
				}
			}
		
			private decimal m_UnitPrice = 0;
			public decimal UnitPrice
			{
				get { return m_UnitPrice;}
				set
				{
					m_UnitPrice = value;
					RaisePropertyChanged("UnitPrice");
				}
			}
		
			private short m_Quantity = 0;
			public short Quantity
			{
				get { return m_Quantity;}
				set
				{
					m_Quantity = value;
					RaisePropertyChanged("Quantity");
				}
			}
		
			private float m_Discount = 0;
			public float Discount
			{
				get { return m_Discount;}
				set
				{
					m_Discount = value;
					RaisePropertyChanged("Discount");
				}
			}
		
			private decimal m_ExtendedPrice = 0;
			public decimal ExtendedPrice
			{
				get { return m_ExtendedPrice;}
				set
				{
					m_ExtendedPrice = value;
					RaisePropertyChanged("ExtendedPrice");
				}
			}
		
			private decimal m_Freight = 0;
			public decimal Freight
			{
				get { return m_Freight;}
				set
				{
					m_Freight = value;
					RaisePropertyChanged("Freight");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}