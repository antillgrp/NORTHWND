/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for OrderDetails
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class OrderDetailsData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public OrderDetailsData() { }
		
		public OrderDetailsData(int orderid,int productid,decimal unitprice,short quantity,float discount)
		{
				this.OrderID = orderid;
			this.ProductID = productid;
			this.UnitPrice = unitprice;
			this.Quantity = quantity;
			this.Discount = discount;

		}

		public OrderDetailsData(IDataReader objReader)
		{
			m_OrderID = (int) (DBNull.Value.Equals(objReader["OrderID"]) ? 0 : objReader["OrderID"]);
			m_ProductID = (int) (DBNull.Value.Equals(objReader["ProductID"]) ? 0 : objReader["ProductID"]);
			m_UnitPrice = (decimal) (DBNull.Value.Equals(objReader["UnitPrice"]) ? 0 : objReader["UnitPrice"]);
			m_Quantity = (short) (DBNull.Value.Equals(objReader["Quantity"]) ? 0 : objReader["Quantity"]);
			m_Discount = (float) (DBNull.Value.Equals(objReader["Discount"]) ? string.Empty : objReader["Discount"]);
		}
		#endregion

		#region Properties
		
			private int m_OrderID = 0;
			public int OrderID
			{
				get { return m_OrderID;}
				set
				{
					m_OrderID = value;
					RaisePropertyChanged("OrderID");
				}
			}
		
			private int m_ProductID = 0;
			public int ProductID
			{
				get { return m_ProductID;}
				set
				{
					m_ProductID = value;
					RaisePropertyChanged("ProductID");
				}
			}
		
			private decimal m_UnitPrice = 0;
			public decimal UnitPrice
			{
				get { return m_UnitPrice;}
				set
				{
					m_UnitPrice = value;
					RaisePropertyChanged("UnitPrice");
				}
			}
		
			private short m_Quantity = 0;
			public short Quantity
			{
				get { return m_Quantity;}
				set
				{
					m_Quantity = value;
					RaisePropertyChanged("Quantity");
				}
			}
		
			private float m_Discount = 0;
			public float Discount
			{
				get { return m_Discount;}
				set
				{
					m_Discount = value;
					RaisePropertyChanged("Discount");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}