/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: This is class contains methods to perform Data Access Layer operations 
 * ------------------------------------------------------------
*/

#region Using Statements	
using System;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
#endregion

namespace Northwind.Model
{
	/// <summary>
	/// Summary description for Region.
	/// </summary>
    public class Region
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["defaultDatabase"].ConnectionString;
		
		#region Constants
		private const string SP_GET_ALL = "SELECT  RegionID, RegionDescription FROM Region WITH (NOLOCK)";
		private const string SP_GET_FILTER = "SELECT  RegionID, RegionDescription FROM Region WITH (NOLOCK) {0}";
		private const string SP_GET_BYPAGE = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY {0}) AS rownumber, * FROM Region {1}) AS tblOutput WHERE rownumber BETWEEN {2} AND {3} SELECT COUNT(*) FROM Region WITH (NOLOCK) {4}";
		private const string SP_GET_BYID = "SELECT  RegionID, RegionDescription FROM Region WITH (NOLOCK) WHERE RegionID = @ref_id";
		private const string SP_ADD = "INSERT INTO Region ( RegionID, RegionDescription) VALUES ( @RegionID, @RegionDescription) ";
		private const string SP_ADD1 = "INSERT INTO Region ( RegionID, RegionDescription) VALUES ( @RegionID, @RegionDescription) SELECT @RegionID = @@IDENTITY";
		private const string SP_UPDATE = "UPDATE Region SET RegionDescription = @RegionDescription WHERE RegionID = @RegionID";
		private const string SP_DELETE = "DELETE FROM Region WHERE RegionID=@ref_id";
		private const string SP_DELETE_FILTER = "DELETE FROM Region {0}";
		private const string SP_GET_LOOKUP = "SELECT RegionID, RegionDescription FROM Region WITH (NOLOCK)";
		#endregion
		
		#region Region - Constructor
		private Region()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#endregion
        
		#region Region - List Region
		/// <summary>
		/// The purpose of this method is to get all Region data.
		/// </summary>
		/// <returns>DataSet object</returns>
		public static DataSet GetData()
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();

                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region Region - List Region by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all Region data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>DataSet object</returns>
		public static DataSet GetData(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region Region - List Region by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all Region data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>DataSet object</returns>
        public static DataSet GetData(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					int lbound = ((pageIndex - 1) * pageSize) +1;
					int ubound = lbound + pageSize - 1;
					string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        rowsCount = Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString());
                        return ds;
                    }
                }
            }
        }
		#endregion
        
        #region Region - Get Details for an Region record
        /// <summary>
		/// The purpose of this method is to get the data based on specified primary key value
		/// </summary>
		/// <param name="sRefID">Primary key value</param>
		/// <returns></returns>
		public static DataSet GetDetails(string sRefID)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					string strSQL = string.Format(SP_GET_BYID, sRefID);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@ref_id", sRefID);
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        //[GET_VALUEBYID_METHOD]
        
        #region Region - Get Lookup Data
        /// <summary>
        /// The purpose of this method is to get the lookup data
        /// </summary>
        /// <returns>returns Lookup Data as DataSet</returns>
        public static DataSet GetLookup()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				using (SqlDataAdapter da = new SqlDataAdapter())
				{
					using (SqlCommand cmd = new SqlCommand(SP_GET_LOOKUP, cn))
					{
						cmd.CommandType = CommandType.Text;
						DataSet ds = new DataSet();

						da.SelectCommand = cmd;
						da.Fill(ds);
						return ds;
					}
				}
            }
        }
        #endregion
		
        
		#region Region - Add Record
        /// <summary>
        /// Creates a new Region row.
        /// </summary>
        public static int Add( int RegionID, string RegionDescription)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_ADD, cn))
                {
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@RegionID", RegionID);
					cmd.Parameters.AddWithValue("@RegionDescription", RegionDescription);
					cn.Open();
					int rowsAffected = cmd.ExecuteNonQuery();
					return (int)cmd.Parameters["@RegionID"].Value;
                }
            }
        }
        #endregion
        
		#region Region - Update Record
        /// <summary>
        /// Updates a Region
        /// </summary>
        public static bool Update( int RegionID, string RegionDescription)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_UPDATE, cn))
                {
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@RegionID", RegionID);
					cmd.Parameters.AddWithValue("@RegionDescription", RegionDescription);
					cn.Open();
					int rowsAffected = cmd.ExecuteNonQuery();
					return (rowsAffected == 1);
                }
            }
        }
        #endregion
        
        #region Region - Delete Record
        /// <summary>
        /// The purpose of this method is to delete the record based on specified primary key value
        /// </summary>
        /// <param name="sRefID">Primary key value</param>
        /// <returns></returns>
        public static bool Delete(string sRefID)
        {
            bool bDeleted = false;
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_DELETE, cn))
                {
                    cmd.CommandType = CommandType.Text;
	                //cmd.Parameters.Add("@RegionID", SqlDbType.int).Value = sRefID;
                    cmd.Parameters.AddWithValue("@ref_id", sRefID);
                    cn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    bDeleted = (rowsAffected == 1);
                }
            }
            return bDeleted;
        }
        #endregion
        
        #region Region - Delete Records
        /// <summary>
        /// The purpose of this method is to delete all Region data based on the Filter Expression criteria.
        /// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
        /// <returns>Returns the number of rows deleted</returns>
        public static int DeleteFilter(string filterExpression)
        {
            int rowsAffected = 0;
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
				string strSQL = string.Format(SP_DELETE_FILTER, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                }
            }
            return rowsAffected;
        }
        #endregion
        
        #region Region - Get List of RegionData objects
        /// <summary>
        /// Returns a collection with all the RegionData
        /// </summary>
		/// <returns>List<RegionData> object</returns>
        public static List<RegionData> GetList()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<RegionData> objList = new List<RegionData>();
					while (reader.Read())
					{
						//objList.Add(new RegionData(
						//	 (int) reader["RegionID"], (string) reader["RegionDescription"]));
						objList.Add(new RegionData(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
        }
        #endregion
        
		
		#region Region - List Region by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all Region data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>List<DataClass> object</returns>
		public static List<RegionData> GetList(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
				string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cmd.Parameters.AddWithValue("@where_clause", filterExpression);
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<RegionData> objList = new List<RegionData>();
					while (reader.Read())
					{
						//objList.Add(new RegionData(
						//	 (int) reader["RegionID"], (string) reader["RegionDescription"]));
						objList.Add(new RegionData(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
		}
		#endregion
		
        #region Region - List Region by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all Region data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>List<RegionData> object</returns>
        public static List<RegionData> GetList(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
                int lbound = ((pageIndex - 1) * pageSize) + 1;
                int ubound = lbound + pageSize - 1;
                string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

                    List<RegionData> objList = new List<RegionData>();
                    while (reader.Read())
                    {
                        //objList.Add(new RegionData(
                        //         (int) reader["RegionID"], (string) reader["RegionDescription"]));
						objList.Add(new RegionData(reader)); // Use this to avoid null issues
                    }
                    reader.NextResult();
                    reader.Read();
                    rowsCount = Convert.ToInt32(reader[0]);
                    reader.Close();

                    return objList;
                }
            }
        }
        #endregion
        
        
		#region Region - Get Details by ID
        /// <summary>
        /// Returns an existing RegionData object with the specified ID 
        /// </summary>
        public static RegionData GetDetailsByID(int sRefID)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(SP_GET_BYID, cn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ref_id", sRefID);
                cn.Open();
                
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    // return new RegionData(
					//	 (int) reader["RegionID"], (string) reader["RegionDescription"]);
					return new RegionData(reader); // Use this to avoid null issues
                }
                else
                    return null;
            }
        }
		#endregion
        
		#region Region - Add Record
        /// <summary>
        /// Creates a new Region
        /// </summary>
        public static int Add(RegionData objRegion)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_ADD, cn))
                {
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@RegionID", objRegion.RegionID);
					cmd.Parameters.AddWithValue("@RegionDescription", objRegion.RegionDescription);
					cn.Open();
					int rowsAffected = cmd.ExecuteNonQuery();
					return (int)cmd.Parameters["@RegionID"].Value;
                }
            }
        }
        #endregion
        
		#region Region - Update Record
		/// <summary>
		/// Updates a Region
		/// </summary>
		public static bool Update(RegionData objRegion)
		{
			using (SqlConnection cn = new SqlConnection(connectionString))
			{
				using (SqlCommand cmd = new SqlCommand(SP_UPDATE, cn))
				{
					cmd.CommandType = CommandType.Text;
					
					cmd.Parameters.AddWithValue("@RegionID", objRegion.RegionID);
					cmd.Parameters.AddWithValue("@RegionDescription", objRegion.RegionDescription);
					cn.Open();
					int rowsAffected = cmd.ExecuteNonQuery();
					return (rowsAffected == 1);
				}
			}
		}
		#endregion
    }
}
  