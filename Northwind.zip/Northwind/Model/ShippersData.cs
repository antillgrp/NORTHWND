/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for Shippers
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class ShippersData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public ShippersData() { }
		
		public ShippersData(int shipperid,string companyname,string phone)
		{
				this.ShipperID = shipperid;
			this.CompanyName = companyname;
			this.Phone = phone;

		}

		public ShippersData(IDataReader objReader)
		{
			m_ShipperID = (int) (DBNull.Value.Equals(objReader["ShipperID"]) ? 0 : objReader["ShipperID"]);
			m_CompanyName = (string) (DBNull.Value.Equals(objReader["CompanyName"]) ? string.Empty : objReader["CompanyName"]);
			m_Phone = (string) (DBNull.Value.Equals(objReader["Phone"]) ? string.Empty : objReader["Phone"]);
		}
		#endregion

		#region Properties
		
			private int m_ShipperID = 0;
			public int ShipperID
			{
				get { return m_ShipperID;}
				set
				{
					m_ShipperID = value;
					RaisePropertyChanged("ShipperID");
				}
			}
		
			private string m_CompanyName = string.Empty;
			public string CompanyName
			{
				get { return m_CompanyName;}
				set
				{
					m_CompanyName = value;
					RaisePropertyChanged("CompanyName");
				}
			}
		
			private string m_Phone = string.Empty;
			public string Phone
			{
				get { return m_Phone;}
				set
				{
					m_Phone = value;
					RaisePropertyChanged("Phone");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}