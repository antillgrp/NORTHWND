/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for ProductsbyCategory
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class ProductsbyCategoryData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public ProductsbyCategoryData() { }
		
		public ProductsbyCategoryData(string categoryname,string productname,string quantityperunit,short unitsinstock,bool discontinued)
		{
				this.CategoryName = categoryname;
			this.ProductName = productname;
			this.QuantityPerUnit = quantityperunit;
			this.UnitsInStock = unitsinstock;
			this.Discontinued = discontinued;

		}

		public ProductsbyCategoryData(IDataReader objReader)
		{
			m_CategoryName = (string) (DBNull.Value.Equals(objReader["CategoryName"]) ? string.Empty : objReader["CategoryName"]);
			m_ProductName = (string) (DBNull.Value.Equals(objReader["ProductName"]) ? string.Empty : objReader["ProductName"]);
			m_QuantityPerUnit = (string) (DBNull.Value.Equals(objReader["QuantityPerUnit"]) ? string.Empty : objReader["QuantityPerUnit"]);
			m_UnitsInStock = (short) (DBNull.Value.Equals(objReader["UnitsInStock"]) ? 0 : objReader["UnitsInStock"]);
			m_Discontinued = (bool) (DBNull.Value.Equals(objReader["Discontinued"]) ? false : objReader["Discontinued"]);
		}
		#endregion

		#region Properties
		
			private string m_CategoryName = string.Empty;
			public string CategoryName
			{
				get { return m_CategoryName;}
				set
				{
					m_CategoryName = value;
					RaisePropertyChanged("CategoryName");
				}
			}
		
			private string m_ProductName = string.Empty;
			public string ProductName
			{
				get { return m_ProductName;}
				set
				{
					m_ProductName = value;
					RaisePropertyChanged("ProductName");
				}
			}
		
			private string m_QuantityPerUnit = string.Empty;
			public string QuantityPerUnit
			{
				get { return m_QuantityPerUnit;}
				set
				{
					m_QuantityPerUnit = value;
					RaisePropertyChanged("QuantityPerUnit");
				}
			}
		
			private short m_UnitsInStock = 0;
			public short UnitsInStock
			{
				get { return m_UnitsInStock;}
				set
				{
					m_UnitsInStock = value;
					RaisePropertyChanged("UnitsInStock");
				}
			}
		
			private bool m_Discontinued = false;
			public bool Discontinued
			{
				get { return m_Discontinued;}
				set
				{
					m_Discontinued = value;
					RaisePropertyChanged("Discontinued");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}