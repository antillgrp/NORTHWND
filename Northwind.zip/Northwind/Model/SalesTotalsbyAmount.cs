/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: This is class contains methods to perform Data Access Layer operations 
 * ------------------------------------------------------------
*/

#region Using Statements	
using System;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
#endregion

namespace Northwind.Model
{
	/// <summary>
	/// Summary description for SalesTotalsbyAmount.
	/// </summary>
    public class SalesTotalsbyAmount
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["defaultDatabase"].ConnectionString;
		
		#region Constants
		private const string SP_GET_ALL = "SELECT  SaleAmount, OrderID, CompanyName, ShippedDate FROM [Sales Totals by Amount] WITH (NOLOCK)";
		private const string SP_GET_FILTER = "SELECT  SaleAmount, OrderID, CompanyName, ShippedDate FROM [Sales Totals by Amount] WITH (NOLOCK) {0}";
		private const string SP_GET_BYPAGE = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY {0}) AS rownumber, * FROM [Sales Totals by Amount] {1}) AS tblOutput WHERE rownumber BETWEEN {2} AND {3} SELECT COUNT(*) FROM [Sales Totals by Amount] WITH (NOLOCK) {4}";
		private const string SP_GET_BYID = "SELECT  SaleAmount, OrderID, CompanyName, ShippedDate FROM [Sales Totals by Amount] WITH (NOLOCK) WHERE SaleAmount = @ref_id";
		private const string SP_ADD = "INSERT INTO [Sales Totals by Amount] ([INSERT_COLUMNS]) VALUES ([INSERT_COLUMN_VALUES]) ";
		private const string SP_ADD1 = "INSERT INTO [Sales Totals by Amount] ([INSERT_COLUMNS]) VALUES ([INSERT_COLUMN_VALUES]) SELECT @SaleAmount = @@IDENTITY";
		private const string SP_UPDATE = "UPDATE [Sales Totals by Amount] SET [TABLE_COLUMNS_UPDATE] WHERE SaleAmount = @SaleAmount";
		private const string SP_DELETE = "DELETE FROM [Sales Totals by Amount] WHERE SaleAmount=@ref_id";
		private const string SP_DELETE_FILTER = "DELETE FROM [Sales Totals by Amount] {0}";
		private const string SP_GET_LOOKUP = "SELECT SaleAmount, CompanyName FROM [Sales Totals by Amount] WITH (NOLOCK)";
		#endregion
		
		#region SalesTotalsbyAmount - Constructor
		private SalesTotalsbyAmount()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#endregion
        
		#region SalesTotalsbyAmount - List SalesTotalsbyAmount
		/// <summary>
		/// The purpose of this method is to get all SalesTotalsbyAmount data.
		/// </summary>
		/// <returns>DataSet object</returns>
		public static DataSet GetData()
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();

                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region SalesTotalsbyAmount - List SalesTotalsbyAmount by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all SalesTotalsbyAmount data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>DataSet object</returns>
		public static DataSet GetData(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        
		#region SalesTotalsbyAmount - List SalesTotalsbyAmount by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all SalesTotalsbyAmount data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>DataSet object</returns>
        public static DataSet GetData(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					filterExpression = (string.IsNullOrEmpty(filterExpression.Trim()) ? string.Empty : "WHERE " + filterExpression);
					int lbound = ((pageIndex - 1) * pageSize) +1;
					int ubound = lbound + pageSize - 1;
					string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        rowsCount = Convert.ToInt32(ds.Tables[1].Rows[0][0].ToString());
                        return ds;
                    }
                }
            }
        }
		#endregion
        
        #region SalesTotalsbyAmount - Get Details for an SalesTotalsbyAmount record
        /// <summary>
		/// The purpose of this method is to get the data based on specified primary key value
		/// </summary>
		/// <param name="sRefID">Primary key value</param>
		/// <returns></returns>
		public static DataSet GetDetails(string sRefID)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
					string strSQL = string.Format(SP_GET_BYID, sRefID);
                    using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@ref_id", sRefID);
                        DataSet ds = new DataSet();
                        da.SelectCommand = cmd;
                        da.Fill(ds);
                        return ds;
                    }
                }
            }
		}
		#endregion
        //[GET_VALUEBYID_METHOD]
        
        #region [Sales Totals by Amount] - Get Lookup Data
        /// <summary>
        /// The purpose of this method is to get the lookup data
        /// </summary>
        /// <returns>returns Lookup Data as DataSet</returns>
        public static DataSet GetLookup()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				using (SqlDataAdapter da = new SqlDataAdapter())
				{
					using (SqlCommand cmd = new SqlCommand(SP_GET_LOOKUP, cn))
					{
						cmd.CommandType = CommandType.Text;
						DataSet ds = new DataSet();

						da.SelectCommand = cmd;
						da.Fill(ds);
						return ds;
					}
				}
            }
        }
        #endregion
		
        
        
        
        
        
        #region [Sales Totals by Amount] - Get List of SalesTotalsbyAmountData objects
        /// <summary>
        /// Returns a collection with all the SalesTotalsbyAmountData
        /// </summary>
		/// <returns>List<SalesTotalsbyAmountData> object</returns>
        public static List<SalesTotalsbyAmountData> GetList()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SP_GET_ALL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<SalesTotalsbyAmountData> objList = new List<SalesTotalsbyAmountData>();
					while (reader.Read())
					{
						//objList.Add(new SalesTotalsbyAmountData(
						//	 (decimal) reader["SaleAmount"], (int) reader["OrderID"], (string) reader["CompanyName"], (DateTime) reader["ShippedDate"]));
						objList.Add(new SalesTotalsbyAmountData(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
        }
        #endregion
        
		
		#region SalesTotalsbyAmount - List SalesTotalsbyAmount by Filter Expression
		/// <summary>
		/// The purpose of this method is to get all SalesTotalsbyAmount data based on the Filter Expression criteria.
		/// </summary>
        /// <param name="filterExpression">A NameValueCollection object that defines various properties.
		/// For example, filterExpression - Where condition to be passed in SQL statement.
		/// </param>
		/// <returns>List<DataClass> object</returns>
		public static List<SalesTotalsbyAmountData> GetList(string filterExpression)
		{
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
				string strSQL = string.Format(SP_GET_FILTER, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
					cmd.CommandType = CommandType.Text;
					cmd.Parameters.AddWithValue("@where_clause", filterExpression);
					cn.Open();
					IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

					List<SalesTotalsbyAmountData> objList = new List<SalesTotalsbyAmountData>();
					while (reader.Read())
					{
						//objList.Add(new SalesTotalsbyAmountData(
						//	 (decimal) reader["SaleAmount"], (int) reader["OrderID"], (string) reader["CompanyName"], (DateTime) reader["ShippedDate"]));
						objList.Add(new SalesTotalsbyAmountData(reader)); // Use this to avoid null issues
					}
					return objList;    
                }
            }
		}
		#endregion
		
        #region [Sales Totals by Amount] - List SalesTotalsbyAmount by filterExpression, sortExpression, pageIndex and pageSize
        /// <summary>
        /// The purpose of this method is to get all SalesTotalsbyAmount data based on filterExpression, sortExpression, pageIndex and pageSize parameters
        /// </summary>
        /// <param name="filterExpression">Where condition to be passed in SQL statement. DO NOT include WHERE keyword.</param>
        /// <param name="sortExpression">Sort column name with direction. For Example, "ProductID ASC")</param>
        /// <param name="pageIndex">Page number to be retrieved. Default is 0.</param>
        /// <param name="pageSize">Number of rows to be retrived. Default is 10.</param>
        /// <param name="rowsCount">Output: Total number of rows exist for the specified criteria.</param>
        /// <returns>List<SalesTotalsbyAmountData> object</returns>
        public static List<SalesTotalsbyAmountData> GetList(string filterExpression, string sortExpression, int pageIndex, int pageSize, out int rowsCount)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
				filterExpression = (string.IsNullOrEmpty(filterExpression) ? string.Empty : "WHERE " + filterExpression.Trim());
                int lbound = ((pageIndex - 1) * pageSize) + 1;
                int ubound = lbound + pageSize - 1;
                string strSQL = string.Format(SP_GET_BYPAGE, sortExpression, filterExpression, lbound, ubound, filterExpression);
                using (SqlCommand cmd = new SqlCommand(strSQL, cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cn.Open();
                    IDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

                    List<SalesTotalsbyAmountData> objList = new List<SalesTotalsbyAmountData>();
                    while (reader.Read())
                    {
                        //objList.Add(new SalesTotalsbyAmountData(
                        //         (decimal) reader["SaleAmount"], (int) reader["OrderID"], (string) reader["CompanyName"], (DateTime) reader["ShippedDate"]));
						objList.Add(new SalesTotalsbyAmountData(reader)); // Use this to avoid null issues
                    }
                    reader.NextResult();
                    reader.Read();
                    rowsCount = Convert.ToInt32(reader[0]);
                    reader.Close();

                    return objList;
                }
            }
        }
        #endregion
        
        
		#region SalesTotalsbyAmount - Get Details by ID
        /// <summary>
        /// Returns an existing SalesTotalsbyAmountData object with the specified ID 
        /// </summary>
        public static SalesTotalsbyAmountData GetDetailsByID(decimal sRefID)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(SP_GET_BYID, cn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ref_id", sRefID);
                cn.Open();
                
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    // return new SalesTotalsbyAmountData(
					//	 (decimal) reader["SaleAmount"], (int) reader["OrderID"], (string) reader["CompanyName"], (DateTime) reader["ShippedDate"]);
					return new SalesTotalsbyAmountData(reader); // Use this to avoid null issues
                }
                else
                    return null;
            }
        }
		#endregion
        
        
    }
}
  