/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for SummaryofSalesbyYear
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class SummaryofSalesbyYearData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public SummaryofSalesbyYearData() { }
		
		public SummaryofSalesbyYearData(DateTime shippeddate,int orderid,decimal subtotal)
		{
				this.ShippedDate = shippeddate;
			this.OrderID = orderid;
			this.Subtotal = subtotal;

		}

		public SummaryofSalesbyYearData(IDataReader objReader)
		{
			m_ShippedDate = (DateTime) (DBNull.Value.Equals(objReader["ShippedDate"]) ? DateTime.MinValue : objReader["ShippedDate"]);
			m_OrderID = (int) (DBNull.Value.Equals(objReader["OrderID"]) ? 0 : objReader["OrderID"]);
			m_Subtotal = (decimal) (DBNull.Value.Equals(objReader["Subtotal"]) ? 0 : objReader["Subtotal"]);
		}
		#endregion

		#region Properties
		
			private DateTime m_ShippedDate = DateTime.MinValue;
			public DateTime ShippedDate
			{
				get { return m_ShippedDate;}
				set
				{
					m_ShippedDate = value;
					RaisePropertyChanged("ShippedDate");
				}
			}
		
			private int m_OrderID = 0;
			public int OrderID
			{
				get { return m_OrderID;}
				set
				{
					m_OrderID = value;
					RaisePropertyChanged("OrderID");
				}
			}
		
			private decimal m_Subtotal = 0;
			public decimal Subtotal
			{
				get { return m_Subtotal;}
				set
				{
					m_Subtotal = value;
					RaisePropertyChanged("Subtotal");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}