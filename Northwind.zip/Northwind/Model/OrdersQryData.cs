/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for OrdersQry
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class OrdersQryData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public OrdersQryData() { }
		
		public OrdersQryData(int orderid,string customerid,int employeeid,DateTime orderdate,DateTime requireddate,DateTime shippeddate,int shipvia,decimal freight,string shipname,string shipaddress,string shipcity,string shipregion,string shippostalcode,string shipcountry,string companyname,string address,string city,string region,string postalcode,string country)
		{
				this.OrderID = orderid;
			this.CustomerID = customerid;
			this.EmployeeID = employeeid;
			this.OrderDate = orderdate;
			this.RequiredDate = requireddate;
			this.ShippedDate = shippeddate;
			this.ShipVia = shipvia;
			this.Freight = freight;
			this.ShipName = shipname;
			this.ShipAddress = shipaddress;
			this.ShipCity = shipcity;
			this.ShipRegion = shipregion;
			this.ShipPostalCode = shippostalcode;
			this.ShipCountry = shipcountry;
			this.CompanyName = companyname;
			this.Address = address;
			this.City = city;
			this.Region = region;
			this.PostalCode = postalcode;
			this.Country = country;

		}

		public OrdersQryData(IDataReader objReader)
		{
			m_OrderID = (int) (DBNull.Value.Equals(objReader["OrderID"]) ? 0 : objReader["OrderID"]);
			m_CustomerID = (string) (DBNull.Value.Equals(objReader["CustomerID"]) ? string.Empty : objReader["CustomerID"]);
			m_EmployeeID = (int) (DBNull.Value.Equals(objReader["EmployeeID"]) ? 0 : objReader["EmployeeID"]);
			m_OrderDate = (DateTime) (DBNull.Value.Equals(objReader["OrderDate"]) ? DateTime.MinValue : objReader["OrderDate"]);
			m_RequiredDate = (DateTime) (DBNull.Value.Equals(objReader["RequiredDate"]) ? DateTime.MinValue : objReader["RequiredDate"]);
			m_ShippedDate = (DateTime) (DBNull.Value.Equals(objReader["ShippedDate"]) ? DateTime.MinValue : objReader["ShippedDate"]);
			m_ShipVia = (int) (DBNull.Value.Equals(objReader["ShipVia"]) ? 0 : objReader["ShipVia"]);
			m_Freight = (decimal) (DBNull.Value.Equals(objReader["Freight"]) ? 0 : objReader["Freight"]);
			m_ShipName = (string) (DBNull.Value.Equals(objReader["ShipName"]) ? string.Empty : objReader["ShipName"]);
			m_ShipAddress = (string) (DBNull.Value.Equals(objReader["ShipAddress"]) ? string.Empty : objReader["ShipAddress"]);
			m_ShipCity = (string) (DBNull.Value.Equals(objReader["ShipCity"]) ? string.Empty : objReader["ShipCity"]);
			m_ShipRegion = (string) (DBNull.Value.Equals(objReader["ShipRegion"]) ? string.Empty : objReader["ShipRegion"]);
			m_ShipPostalCode = (string) (DBNull.Value.Equals(objReader["ShipPostalCode"]) ? string.Empty : objReader["ShipPostalCode"]);
			m_ShipCountry = (string) (DBNull.Value.Equals(objReader["ShipCountry"]) ? string.Empty : objReader["ShipCountry"]);
			m_CompanyName = (string) (DBNull.Value.Equals(objReader["CompanyName"]) ? string.Empty : objReader["CompanyName"]);
			m_Address = (string) (DBNull.Value.Equals(objReader["Address"]) ? string.Empty : objReader["Address"]);
			m_City = (string) (DBNull.Value.Equals(objReader["City"]) ? string.Empty : objReader["City"]);
			m_Region = (string) (DBNull.Value.Equals(objReader["Region"]) ? string.Empty : objReader["Region"]);
			m_PostalCode = (string) (DBNull.Value.Equals(objReader["PostalCode"]) ? string.Empty : objReader["PostalCode"]);
			m_Country = (string) (DBNull.Value.Equals(objReader["Country"]) ? string.Empty : objReader["Country"]);
		}
		#endregion

		#region Properties
		
			private int m_OrderID = 0;
			public int OrderID
			{
				get { return m_OrderID;}
				set
				{
					m_OrderID = value;
					RaisePropertyChanged("OrderID");
				}
			}
		
			private string m_CustomerID = string.Empty;
			public string CustomerID
			{
				get { return m_CustomerID;}
				set
				{
					m_CustomerID = value;
					RaisePropertyChanged("CustomerID");
				}
			}
		
			private int m_EmployeeID = 0;
			public int EmployeeID
			{
				get { return m_EmployeeID;}
				set
				{
					m_EmployeeID = value;
					RaisePropertyChanged("EmployeeID");
				}
			}
		
			private DateTime m_OrderDate = DateTime.MinValue;
			public DateTime OrderDate
			{
				get { return m_OrderDate;}
				set
				{
					m_OrderDate = value;
					RaisePropertyChanged("OrderDate");
				}
			}
		
			private DateTime m_RequiredDate = DateTime.MinValue;
			public DateTime RequiredDate
			{
				get { return m_RequiredDate;}
				set
				{
					m_RequiredDate = value;
					RaisePropertyChanged("RequiredDate");
				}
			}
		
			private DateTime m_ShippedDate = DateTime.MinValue;
			public DateTime ShippedDate
			{
				get { return m_ShippedDate;}
				set
				{
					m_ShippedDate = value;
					RaisePropertyChanged("ShippedDate");
				}
			}
		
			private int m_ShipVia = 0;
			public int ShipVia
			{
				get { return m_ShipVia;}
				set
				{
					m_ShipVia = value;
					RaisePropertyChanged("ShipVia");
				}
			}
		
			private decimal m_Freight = 0;
			public decimal Freight
			{
				get { return m_Freight;}
				set
				{
					m_Freight = value;
					RaisePropertyChanged("Freight");
				}
			}
		
			private string m_ShipName = string.Empty;
			public string ShipName
			{
				get { return m_ShipName;}
				set
				{
					m_ShipName = value;
					RaisePropertyChanged("ShipName");
				}
			}
		
			private string m_ShipAddress = string.Empty;
			public string ShipAddress
			{
				get { return m_ShipAddress;}
				set
				{
					m_ShipAddress = value;
					RaisePropertyChanged("ShipAddress");
				}
			}
		
			private string m_ShipCity = string.Empty;
			public string ShipCity
			{
				get { return m_ShipCity;}
				set
				{
					m_ShipCity = value;
					RaisePropertyChanged("ShipCity");
				}
			}
		
			private string m_ShipRegion = string.Empty;
			public string ShipRegion
			{
				get { return m_ShipRegion;}
				set
				{
					m_ShipRegion = value;
					RaisePropertyChanged("ShipRegion");
				}
			}
		
			private string m_ShipPostalCode = string.Empty;
			public string ShipPostalCode
			{
				get { return m_ShipPostalCode;}
				set
				{
					m_ShipPostalCode = value;
					RaisePropertyChanged("ShipPostalCode");
				}
			}
		
			private string m_ShipCountry = string.Empty;
			public string ShipCountry
			{
				get { return m_ShipCountry;}
				set
				{
					m_ShipCountry = value;
					RaisePropertyChanged("ShipCountry");
				}
			}
		
			private string m_CompanyName = string.Empty;
			public string CompanyName
			{
				get { return m_CompanyName;}
				set
				{
					m_CompanyName = value;
					RaisePropertyChanged("CompanyName");
				}
			}
		
			private string m_Address = string.Empty;
			public string Address
			{
				get { return m_Address;}
				set
				{
					m_Address = value;
					RaisePropertyChanged("Address");
				}
			}
		
			private string m_City = string.Empty;
			public string City
			{
				get { return m_City;}
				set
				{
					m_City = value;
					RaisePropertyChanged("City");
				}
			}
		
			private string m_Region = string.Empty;
			public string Region
			{
				get { return m_Region;}
				set
				{
					m_Region = value;
					RaisePropertyChanged("Region");
				}
			}
		
			private string m_PostalCode = string.Empty;
			public string PostalCode
			{
				get { return m_PostalCode;}
				set
				{
					m_PostalCode = value;
					RaisePropertyChanged("PostalCode");
				}
			}
		
			private string m_Country = string.Empty;
			public string Country
			{
				get { return m_Country;}
				set
				{
					m_Country = value;
					RaisePropertyChanged("Country");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}