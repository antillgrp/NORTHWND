/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for Territories
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class TerritoriesData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public TerritoriesData() { }
		
		public TerritoriesData(string territoryid,string territorydescription,int regionid)
		{
				this.TerritoryID = territoryid;
			this.TerritoryDescription = territorydescription;
			this.RegionID = regionid;

		}

		public TerritoriesData(IDataReader objReader)
		{
			m_TerritoryID = (string) (DBNull.Value.Equals(objReader["TerritoryID"]) ? string.Empty : objReader["TerritoryID"]);
			m_TerritoryDescription = (string) (DBNull.Value.Equals(objReader["TerritoryDescription"]) ? string.Empty : objReader["TerritoryDescription"]);
			m_RegionID = (int) (DBNull.Value.Equals(objReader["RegionID"]) ? 0 : objReader["RegionID"]);
		}
		#endregion

		#region Properties
		
			private string m_TerritoryID = string.Empty;
			public string TerritoryID
			{
				get { return m_TerritoryID;}
				set
				{
					m_TerritoryID = value;
					RaisePropertyChanged("TerritoryID");
				}
			}
		
			private string m_TerritoryDescription = string.Empty;
			public string TerritoryDescription
			{
				get { return m_TerritoryDescription;}
				set
				{
					m_TerritoryDescription = value;
					RaisePropertyChanged("TerritoryDescription");
				}
			}
		
			private int m_RegionID = 0;
			public int RegionID
			{
				get { return m_RegionID;}
				set
				{
					m_RegionID = value;
					RaisePropertyChanged("RegionID");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}