/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for CustomerandSuppliersbyCity
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class CustomerandSuppliersbyCityData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public CustomerandSuppliersbyCityData() { }
		
		public CustomerandSuppliersbyCityData(string city,string companyname,string contactname,string relationship)
		{
				this.City = city;
			this.CompanyName = companyname;
			this.ContactName = contactname;
			this.Relationship = relationship;

		}

		public CustomerandSuppliersbyCityData(IDataReader objReader)
		{
			m_City = (string) (DBNull.Value.Equals(objReader["City"]) ? string.Empty : objReader["City"]);
			m_CompanyName = (string) (DBNull.Value.Equals(objReader["CompanyName"]) ? string.Empty : objReader["CompanyName"]);
			m_ContactName = (string) (DBNull.Value.Equals(objReader["ContactName"]) ? string.Empty : objReader["ContactName"]);
			m_Relationship = (string) (DBNull.Value.Equals(objReader["Relationship"]) ? string.Empty : objReader["Relationship"]);
		}
		#endregion

		#region Properties
		
			private string m_City = string.Empty;
			public string City
			{
				get { return m_City;}
				set
				{
					m_City = value;
					RaisePropertyChanged("City");
				}
			}
		
			private string m_CompanyName = string.Empty;
			public string CompanyName
			{
				get { return m_CompanyName;}
				set
				{
					m_CompanyName = value;
					RaisePropertyChanged("CompanyName");
				}
			}
		
			private string m_ContactName = string.Empty;
			public string ContactName
			{
				get { return m_ContactName;}
				set
				{
					m_ContactName = value;
					RaisePropertyChanged("ContactName");
				}
			}
		
			private string m_Relationship = string.Empty;
			public string Relationship
			{
				get { return m_Relationship;}
				set
				{
					m_Relationship = value;
					RaisePropertyChanged("Relationship");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}