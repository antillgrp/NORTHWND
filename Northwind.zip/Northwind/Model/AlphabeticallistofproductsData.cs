/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for Alphabeticallistofproducts
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class AlphabeticallistofproductsData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public AlphabeticallistofproductsData() { }
		
		public AlphabeticallistofproductsData(int productid,string productname,int supplierid,int categoryid,string quantityperunit,decimal unitprice,short unitsinstock,short unitsonorder,short reorderlevel,bool discontinued,string categoryname)
		{
				this.ProductID = productid;
			this.ProductName = productname;
			this.SupplierID = supplierid;
			this.CategoryID = categoryid;
			this.QuantityPerUnit = quantityperunit;
			this.UnitPrice = unitprice;
			this.UnitsInStock = unitsinstock;
			this.UnitsOnOrder = unitsonorder;
			this.ReorderLevel = reorderlevel;
			this.Discontinued = discontinued;
			this.CategoryName = categoryname;

		}

		public AlphabeticallistofproductsData(IDataReader objReader)
		{
			m_ProductID = (int) (DBNull.Value.Equals(objReader["ProductID"]) ? 0 : objReader["ProductID"]);
			m_ProductName = (string) (DBNull.Value.Equals(objReader["ProductName"]) ? string.Empty : objReader["ProductName"]);
			m_SupplierID = (int) (DBNull.Value.Equals(objReader["SupplierID"]) ? 0 : objReader["SupplierID"]);
			m_CategoryID = (int) (DBNull.Value.Equals(objReader["CategoryID"]) ? 0 : objReader["CategoryID"]);
			m_QuantityPerUnit = (string) (DBNull.Value.Equals(objReader["QuantityPerUnit"]) ? string.Empty : objReader["QuantityPerUnit"]);
			m_UnitPrice = (decimal) (DBNull.Value.Equals(objReader["UnitPrice"]) ? 0 : objReader["UnitPrice"]);
			m_UnitsInStock = (short) (DBNull.Value.Equals(objReader["UnitsInStock"]) ? 0 : objReader["UnitsInStock"]);
			m_UnitsOnOrder = (short) (DBNull.Value.Equals(objReader["UnitsOnOrder"]) ? 0 : objReader["UnitsOnOrder"]);
			m_ReorderLevel = (short) (DBNull.Value.Equals(objReader["ReorderLevel"]) ? 0 : objReader["ReorderLevel"]);
			m_Discontinued = (bool) (DBNull.Value.Equals(objReader["Discontinued"]) ? false : objReader["Discontinued"]);
			m_CategoryName = (string) (DBNull.Value.Equals(objReader["CategoryName"]) ? string.Empty : objReader["CategoryName"]);
		}
		#endregion

		#region Properties
		
			private int m_ProductID = 0;
			public int ProductID
			{
				get { return m_ProductID;}
				set
				{
					m_ProductID = value;
					RaisePropertyChanged("ProductID");
				}
			}
		
			private string m_ProductName = string.Empty;
			public string ProductName
			{
				get { return m_ProductName;}
				set
				{
					m_ProductName = value;
					RaisePropertyChanged("ProductName");
				}
			}
		
			private int m_SupplierID = 0;
			public int SupplierID
			{
				get { return m_SupplierID;}
				set
				{
					m_SupplierID = value;
					RaisePropertyChanged("SupplierID");
				}
			}
		
			private int m_CategoryID = 0;
			public int CategoryID
			{
				get { return m_CategoryID;}
				set
				{
					m_CategoryID = value;
					RaisePropertyChanged("CategoryID");
				}
			}
		
			private string m_QuantityPerUnit = string.Empty;
			public string QuantityPerUnit
			{
				get { return m_QuantityPerUnit;}
				set
				{
					m_QuantityPerUnit = value;
					RaisePropertyChanged("QuantityPerUnit");
				}
			}
		
			private decimal m_UnitPrice = 0;
			public decimal UnitPrice
			{
				get { return m_UnitPrice;}
				set
				{
					m_UnitPrice = value;
					RaisePropertyChanged("UnitPrice");
				}
			}
		
			private short m_UnitsInStock = 0;
			public short UnitsInStock
			{
				get { return m_UnitsInStock;}
				set
				{
					m_UnitsInStock = value;
					RaisePropertyChanged("UnitsInStock");
				}
			}
		
			private short m_UnitsOnOrder = 0;
			public short UnitsOnOrder
			{
				get { return m_UnitsOnOrder;}
				set
				{
					m_UnitsOnOrder = value;
					RaisePropertyChanged("UnitsOnOrder");
				}
			}
		
			private short m_ReorderLevel = 0;
			public short ReorderLevel
			{
				get { return m_ReorderLevel;}
				set
				{
					m_ReorderLevel = value;
					RaisePropertyChanged("ReorderLevel");
				}
			}
		
			private bool m_Discontinued = false;
			public bool Discontinued
			{
				get { return m_Discontinued;}
				set
				{
					m_Discontinued = value;
					RaisePropertyChanged("Discontinued");
				}
			}
		
			private string m_CategoryName = string.Empty;
			public string CategoryName
			{
				get { return m_CategoryName;}
				set
				{
					m_CategoryName = value;
					RaisePropertyChanged("CategoryName");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}