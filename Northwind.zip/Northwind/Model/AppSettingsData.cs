/* ------------------------------------------------------------
 * Created By	: CodeBhagat v1.0
 * Created Date	: 8/4/2014
 * Purpose		: WPF Model Entity class for AppSettings
 * ------------------------------------------------------------
*/

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace Northwind.Model
{
	public class AppSettingsData : INotifyPropertyChanged, IDataErrorInfo
	{
		protected Dictionary<string, string> ErrorDictionary = new Dictionary<string, string>();
		
        public event PropertyChangedEventHandler PropertyChanged;
		void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) 
			{ 
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
			}
        }

		#region Constructor
		public AppSettingsData() { }
		
		public AppSettingsData(long optionid,string keyname,string keyvalue,string comments,DateTime createddate,DateTime updateddate)
		{
				this.OptionID = optionid;
			this.KeyName = keyname;
			this.KeyValue = keyvalue;
			this.Comments = comments;
			this.CreatedDate = createddate;
			this.UpdatedDate = updateddate;

		}

		public AppSettingsData(IDataReader objReader)
		{
			m_OptionID = (long) (DBNull.Value.Equals(objReader["OptionID"]) ? 0 : objReader["OptionID"]);
			m_KeyName = (string) (DBNull.Value.Equals(objReader["KeyName"]) ? string.Empty : objReader["KeyName"]);
			m_KeyValue = (string) (DBNull.Value.Equals(objReader["KeyValue"]) ? string.Empty : objReader["KeyValue"]);
			m_Comments = (string) (DBNull.Value.Equals(objReader["Comments"]) ? string.Empty : objReader["Comments"]);
			m_CreatedDate = (DateTime) (DBNull.Value.Equals(objReader["CreatedDate"]) ? DateTime.MinValue : objReader["CreatedDate"]);
			m_UpdatedDate = (DateTime) (DBNull.Value.Equals(objReader["UpdatedDate"]) ? DateTime.MinValue : objReader["UpdatedDate"]);
		}
		#endregion

		#region Properties
		
			private long m_OptionID = 0;
			public long OptionID
			{
				get { return m_OptionID;}
				set
				{
					m_OptionID = value;
					RaisePropertyChanged("OptionID");
				}
			}
		
			private string m_KeyName = string.Empty;
			public string KeyName
			{
				get { return m_KeyName;}
				set
				{
					m_KeyName = value;
					RaisePropertyChanged("KeyName");
				}
			}
		
			private string m_KeyValue = string.Empty;
			public string KeyValue
			{
				get { return m_KeyValue;}
				set
				{
					m_KeyValue = value;
					RaisePropertyChanged("KeyValue");
				}
			}
		
			private string m_Comments = string.Empty;
			public string Comments
			{
				get { return m_Comments;}
				set
				{
					m_Comments = value;
					RaisePropertyChanged("Comments");
				}
			}
		
			private DateTime m_CreatedDate = DateTime.MinValue;
			public DateTime CreatedDate
			{
				get { return m_CreatedDate;}
				set
				{
					m_CreatedDate = value;
					RaisePropertyChanged("CreatedDate");
				}
			}
		
			private DateTime m_UpdatedDate = DateTime.MinValue;
			public DateTime UpdatedDate
			{
				get { return m_UpdatedDate;}
				set
				{
					m_UpdatedDate = value;
					RaisePropertyChanged("UpdatedDate");
				}
			}
		
		#endregion
		
		#region IDataErrorInfo Members
		string IDataErrorInfo.Error
		{
			get { return (this as IDataErrorInfo).Error; }
		}

		string IDataErrorInfo.this[string propertyName]
		{
			get
			{
				//string error = (this as IDataErrorInfo)[propertyName];
				string error = this.GetValidationError(propertyName);

				// Dirty the commands registered with CommandManager,
				// such as our Save command, so that they are queried
				// to see if they can execute now.
				CommandManager.InvalidateRequerySuggested();

				return error;
			}
		}

		public bool IsValid
		{
			get
			{
				/*foreach (string property in ValidatedProperties)
					if (GetValidationError(property) != null)
						return false;*/
				if (this.ErrorDictionary.Count > 0)
					return false;
				return true;
			}
		}

		private bool _isSelected;
		public bool IsSelected
		{
			get { return _isSelected; }
			set
			{
				_isSelected = value;
				RaisePropertyChanged("IsSelected");
			}
		}
		
		static readonly string[] ValidatedProperties = { /* List Properties */ };
		string GetValidationError(string propertyName)
		{
			if (Array.IndexOf(ValidatedProperties, propertyName) < 0)
				return null;
			string error = null;
			switch (propertyName)
			{
				default:
					Debug.Fail("Unexpected property being validated on Customer: " + propertyName);
					break;
			}
			return error;
		}
		#endregion
	}
}